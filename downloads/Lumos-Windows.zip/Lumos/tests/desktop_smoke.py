"""Real desktop supervisor and browser sign-in, exercised on Linux.
Windows-native CMD/Job Object/MSVC execution still requires a Windows machine.
"""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import httpx
from playwright.sync_api import sync_playwright
from scripts.desktop import browser_ticket

root=Path(__file__).resolve().parents[1]
port,model_port=18987,18988
base=f'http://127.0.0.1:{port}'
command=[sys.executable,str(root/'scripts/desktop.py'),'--port',str(port),'--model-port',str(model_port),'--no-browser']
with tempfile.TemporaryDirectory(prefix='lumos-desktop-') as profile:
    env=os.environ.copy();env['LUMOS_DATA_DIR']=profile
    process=subprocess.Popen(command,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    try:
        deadline=time.monotonic()+60
        while time.monotonic()<deadline:
            if process.poll() is not None:raise AssertionError(process.communicate()[0])
            try:
                response=httpx.get(base+'/health',trust_env=False,timeout=1)
                if response.status_code==200:break
            except httpx.HTTPError:pass
            time.sleep(.2)
        else:raise AssertionError('Desktop did not start')
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
            page=browser.new_page();errors=[]
            page.on('pageerror',lambda error:errors.append(str(error)))
            page.goto(browser_ticket(base,Path(profile)))
            page.locator('#workspace').wait_for(state='visible')
            assert page.locator('#login').is_hidden()
            assert '#' not in page.url
            page.locator('#message').fill('Réponds en français en une phrase : quelle est la capitale de la France ?')
            page.locator('#send').click()
            page.locator('#messages').get_by_text('Paris',exact=False).wait_for(timeout=60000)
            assert not errors,errors
            browser.close()
        second=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,timeout=15)
        assert second.returncode==0,second.stdout+second.stderr
        assert process.poll() is None,'Second launch must not stop first launcher'
        assert httpx.get(base+'/health',trust_env=False).status_code==200
        print('Desktop smoke: owned model and API started, browser signed in without owner code, URL cleared, real French response, second launch reused services.')
    finally:
        if process.poll() is None:process.send_signal(signal.SIGINT)
        try:output=process.communicate(timeout=20)[0]
        except subprocess.TimeoutExpired:process.kill();output=process.communicate()[0]
        # No authentication tokens or owner codes are emitted by the supervisor.
        secret=(Path(profile)/'owner-code').read_text() if (Path(profile)/'owner-code').exists() else ''
        assert not secret or secret not in output
        for endpoint in [base,f'http://127.0.0.1:{model_port}']:
            try:r=httpx.get(endpoint+'/health',trust_env=False,timeout=1)
            except httpx.HTTPError:continue
            raise AssertionError('An owned service survived shutdown')
print('Desktop shutdown passed: only supervised services were stopped.')
