"""Real browser + real server. No model fixture; missing-model error is expected.
Run only against a disposable LUMOS_DATA_DIR, as this creates test records.
"""
import json
import os
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
code = (Path(os.environ['LUMOS_DATA_DIR']) / 'owner-code').read_text().strip()
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1440, 'height': 1000}, reduced_motion='reduce')
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto('http://127.0.0.1:8000')
    page.locator('#code').fill(code)
    page.locator('#login-form button').click()
    page.locator('#workspace').wait_for(state='visible')
    page.locator('#message').fill('/tache Test navigateur — préparer mes affaires')
    page.locator('#send').click()
    page.get_by_text('Aucun rappel système n’a été programmé.', exact=False).first.wait_for()
    page.locator('[data-view="tasks"]').click()
    page.locator('.task-row').filter(has_text='Test navigateur').wait_for()
    page.locator('.task-row input').first.check()
    page.locator('.task-row.done').first.wait_for()
    page.locator('[data-view="memory"]').click()
    page.locator('#memory-content').fill('Fixture navigateur : iPhone 12')
    page.locator('#memory-form button').click()
    page.locator('.memory-row').filter(has_text='Fixture navigateur').wait_for()
    page.locator('[data-view="activity"]').click()
    page.locator('#actions code').first.wait_for()
    page.locator('[data-view="chat"]').click()
    real_model = os.getenv('LUMOS_SMOKE_REAL_MODEL') == '1'
    page.locator('#message').fill('Réponds en français en une phrase : quelle est la capitale de la France ?' if real_model else 'Bonjour Lumos')
    page.locator('#send').click()
    if real_model:
        page.locator('#messages').get_by_text('Paris', exact=False).wait_for(timeout=120000)
    else:
        page.locator('#messages').get_by_text('Le modèle local est absent ou injoignable.', exact=False).wait_for()
    page.locator('[data-view="settings"]').click()
    page.locator('#capabilities').get_by_text('Disponible ·' if real_model else 'Modèle local absent ou injoignable', exact=False).first.wait_for()
    with page.expect_download() as result:
        page.locator('#export').click()
    export_file = result.value.path()
    archive = json.loads(Path(export_file).read_text())
    assert len(archive['tasks']) == 1 and archive['tasks'][0]['status'] == 'done'
    assert len(archive['messages']) == 4
    assert ('Paris' in archive['messages'][-1]['content']) if real_model else not archive['messages'][-1]['content']
    page.locator('[data-view="chat"]').click()
    page.screenshot(path='/tmp/lumos-desktop.png', full_page=True)
    page.set_viewport_size({'width':390,'height':844})
    page.screenshot(path='/tmp/lumos-mobile.png', full_page=True)
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    page.locator('[data-view="tasks"]').click()
    page.locator('.task-row').first.wait_for(state='visible')
    assert not errors, errors
    browser.close()
print('Browser smoke passed: login, real task, completion, memory, action evidence,',
      'real local model' if real_model else 'missing model',
      ', export, mobile layout. No audio validation.')
