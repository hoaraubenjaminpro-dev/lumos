"""Real French synthetic audio -> real local Whisper. Not a physical-microphone test.
Optional espeakng-loader 0.2.4 is used only to generate a deterministic audio fixture.
"""
import ctypes as C
import io
import os
from pathlib import Path
import tempfile
import time
import wave
import espeakng_loader
from fastapi.testclient import TestClient
from services.lumos_server.app import create_app

lib=espeakng_loader.load_library()
lib.espeak_Initialize.argtypes=[C.c_int,C.c_int,C.c_char_p,C.c_int]
rate=lib.espeak_Initialize(2,0,str(espeakng_loader.get_data_path()).encode(),0)
assert rate > 0
chunks=[]
CALLBACK=C.CFUNCTYPE(C.c_int,C.POINTER(C.c_short),C.c_int,C.c_void_p)
@CALLBACK
def collect(samples,count,events):
    if samples and count:
        chunks.append(C.string_at(samples,count*2))
    return 0
lib.espeak_SetSynthCallback(collect)
lib.espeak_SetVoiceByName.argtypes=[C.c_char_p]
assert lib.espeak_SetVoiceByName(b'fr')==0
lib.espeak_SetParameter(1,145,0)  # speaking rate
text='Bonjour Lumos. Je voudrais préparer mes affaires pour demain.'.encode()
lib.espeak_Synth.argtypes=[C.c_char_p,C.c_size_t,C.c_uint,C.c_int,C.c_uint,C.c_uint,C.c_void_p,C.c_void_p]
assert lib.espeak_Synth(text,len(text)+1,0,1,0,1,None,None)==0
output=io.BytesIO()
with wave.open(output,'wb') as wav:
    wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(rate);wav.writeframes(b''.join(chunks))
assert len(output.getvalue())>10000
os.environ['LUMOS_WHISPER_DIR']=str(Path(__file__).resolve().parents[1]/'.data/models/whisper-small')
with tempfile.TemporaryDirectory(prefix='lumos-real-speech-') as profile:
    app=create_app(profile)
    with TestClient(app,headers={'X-Lumos-Request':'1'}) as c:
        c.post('/auth/login',json={'code':app.state.code})
        start=time.perf_counter()
        response=c.post('/v1/audio/transcribe',files={'audio':('synthetic-french.wav',output.getvalue(),'audio/wav')})
        assert response.status_code==200,response.text
        transcript=response.json()['text']
        print('Real local STT transcript (synthetic fixture):',transcript)
        print('Cold local STT elapsed seconds:',round(time.perf_counter()-start,2))
        assert 'affaires' in transcript.lower(),transcript
        assert 'demain' in transcript.lower(),transcript
        assert c.get('/v1/tasks').json()==[]
        assert c.get('/v1/conversations').json()==[]
print('Real local speech smoke passed. Physical microphone, browser speaker and barge-in remain untested.')
