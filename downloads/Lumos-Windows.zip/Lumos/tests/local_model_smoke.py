"""Explicit real-model check; requires local llama.cpp and downloaded model."""
import json
import os
import tempfile
from fastapi.testclient import TestClient
from services.lumos_server.app import create_app

os.environ['LUMOS_BACKEND'] = 'llamacpp'
os.environ['LUMOS_WHISPER_DIR'] = str(__import__('pathlib').Path(__file__).resolve().parents[1] / '.data/models/whisper-small')
with tempfile.TemporaryDirectory(prefix='lumos-real-model-') as profile:
    app = create_app(profile)
    with TestClient(app, headers={'X-Lumos-Request': '1'}) as c:
        c.post('/auth/login', json={'code': app.state.code})
        cap = c.get('/v1/capabilities').json()
        assert cap['text'] is True and cap['speech_input'] is True, cap
        cid = c.post('/v1/conversations', json={}).json()['id']
        response = c.post(f'/v1/conversations/{cid}/messages', json={
            'content': 'Réponds en français en une phrase : quelle est la capitale de la France ?',
            'client_id': str(__import__('uuid').uuid4()),
        })
        events = [json.loads(line) for line in response.text.splitlines()]
        assert events[-1]['type'] == 'turn.complete', events
        text = next(e['text'] for e in events if e['type'] == 'assistant.text')
        assert 'Paris' in text, text
        print('Real local model reply:', text)
        assert c.get('/v1/tasks').json() == []
        archive = c.post('/v1/exports').json()
        assert archive['messages'][-1]['content'] == text
        print('Real local model smoke passed: authenticated API, French factual answer, persisted reply, no unrequested task, export.')
