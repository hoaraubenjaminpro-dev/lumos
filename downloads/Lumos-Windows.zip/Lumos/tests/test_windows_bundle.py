import hashlib
import io
from pathlib import Path
import zipfile
import pytest
from scripts.windows_setup import download_verified, extract_verified_zip
from scripts.build_windows_bundle import build, write_launcher


def test_download_cached_valid_and_refuses_modified(tmp_path):
    path=tmp_path/'artifact.zip';path.write_bytes(b'official artifact fixture')
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    assert download_verified('https://unused.invalid',path,digest)==path
    path.write_bytes(b'modified')
    with pytest.raises(RuntimeError):
        download_verified('https://unused.invalid',path,digest)


@pytest.mark.parametrize('name',['../escape.exe','/escape.exe','C:/escape.exe','dir\\escape.exe'])
def test_extract_rejects_unsafe_paths(tmp_path,name):
    path=tmp_path/'input.zip'
    with zipfile.ZipFile(path,'w') as archive:archive.writestr(name,b'bad')
    with pytest.raises(RuntimeError):extract_verified_zip(path,tmp_path/'runtime')
    assert not (tmp_path/'escape.exe').exists()


def test_extract_restores_only_declared_files(tmp_path):
    path=tmp_path/'input.zip';target=tmp_path/'runtime';target.mkdir()
    (target/'user-note.txt').write_text('keep')
    with zipfile.ZipFile(path,'w') as archive:archive.writestr('llama-server.exe',b'fixture executable')
    extract_verified_zip(path,target)
    (target/'llama-server.exe').write_bytes(b'modified')
    extract_verified_zip(path,target)
    assert (target/'llama-server.exe').read_bytes()==b'fixture executable'
    assert (target/'user-note.txt').read_text()=='keep'


def test_bundle_excludes_data_secrets_and_local_configuration(tmp_path):
    root=tmp_path/'source';root.mkdir();(root/'scripts').mkdir();(root/'apps').mkdir()
    (root/'scripts/bootstrap_windows.ps1').write_text("Write-Host 'Lumos';")
    (root/'apps/index.html').write_text('Lumos')
    (root/'README.md').write_text('readme')
    (root/'.data').mkdir();(root/'.data/owner-code').write_text('SECRET_SENTINEL')
    (root/'.venv').mkdir();(root/'.venv/private.txt').write_text('SECRET_SENTINEL')
    (root/'.env').write_text('SECRET_SENTINEL')
    (root/'apps/notes.log').write_text('SECRET_SENTINEL')
    result,_=build(tmp_path/'out.zip',root)
    with zipfile.ZipFile(result) as archive:
        assert 'Lumos/Demarrer Lumos.cmd' in archive.namelist()
        assert 'Lumos/apps/index.html' in archive.namelist()
        assert not any(b'SECRET_SENTINEL' in archive.read(n) for n in archive.namelist())
        launcher=archive.read('Lumos/Demarrer Lumos.cmd').decode()
        assert 'ExecutionPolicy' not in launcher
        assert 'powershell.exe -NoLogo -NoProfile -Command' in launcher


def test_windows_dependency_closure_includes_platform_only_packages(tmp_path):
    from scripts.check_windows_dependencies import validate
    wheels=tmp_path/'wheels';wheels.mkdir()
    dependencies={'pytest':('8.3.5','colorama; sys_platform == "win32"'),
                  'tqdm':('4.70.1','colorama; platform_system == "Windows"'),
                  'colorama':('0.4.6',None)}
    for name,(version,requirement) in dependencies.items():
        with zipfile.ZipFile(wheels/(name+'.whl'),'w') as archive:
            metadata=f'Metadata-Version: 2.1\nName: {name}\nVersion: {version}\n'
            if requirement:metadata+='Requires-Dist: '+requirement+'\n'
            archive.writestr(f'{name}-{version}.dist-info/METADATA',metadata)
    lock=tmp_path/'requirements.lock'
    lock.write_text('pytest==8.3.5\ntqdm==4.70.1\n')
    errors,count=validate(lock,wheels)
    assert count==2 and len(errors)==2
    assert all('colorama' in error for error in errors)
    lock.write_text(lock.read_text()+"colorama==0.4.6; sys_platform == 'win32'\n")
    assert validate(lock,wheels)==([],3)
