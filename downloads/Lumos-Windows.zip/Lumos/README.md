# Lumos

Une première tranche de l’assistant personnel de Chris, en français, sans API payante obligatoire. Serveur Python/FastAPI, interface web responsive et SQLite. Le cahier des charges complet est dans [docs/PRODUCT.md](docs/PRODUCT.md).

**État honnête :** tâches, historique, carnet mémoire, export/restauration et interface testés. Conversation texte avec un vrai modèle local vérifiée, ainsi que la transcription locale sur un échantillon français synthétique. Voix au micro, sortie audio du navigateur et interruption sur matériel **non vérifiées**. Ce n’est pas encore l’ensemble du produit décrit dans le cahier des charges.

## Essai Windows sans terminal à configurer

Extraire le paquet Windows, puis double-cliquer sur **Demarrer Lumos.cmd**. Le premier lancement prépare Python local, les dépendances, le moteur et les modèles, puis ouvre le navigateur avec une connexion automatique à usage unique. Aucun code propriétaire à copier. Le lanceur ne modifie pas la politique PowerShell ; les exécutables téléchargés sont contrôlés avant exécution. Un composant Microsoft signé peut nécessiter une autorisation Windows s’il manque.

Prévoir Internet au premier lancement et 4 Go libres. Les lancements suivants réutilisent les fichiers vérifiés, y compris sans Internet. Garder la fenêtre ouverte pendant l’essai ; Ctrl+C ou sa fermeture arrête les services démarrés par le lanceur. Un raccourci Bureau est créé si Windows l’autorise. Voir `LIRE-MOI-WINDOWS.txt`.

Cible : Windows 10/11 Intel/AMD 64 bits. Le superviseur et la connexion navigateur ont été vérifiés sur Linux, les archives et roues Windows sont disponibles et leurs empreintes contrôlées ; **l’exécution native Windows reste à confirmer**.

## Démarrage minimal — Linux / macOS, Python 3.12

```sh
bash scripts/setup.sh
.venv/bin/python scripts/run.py
```

Dans un autre terminal, affiche le code personnel **uniquement sur ton terminal** :

```sh
.venv/bin/python scripts/owner_code.py
```

Ouvre le serveur local sur le port 8000 dans ton navigateur, puis saisis ce code. Aucun micro ne s’active au lancement. Crée une tâche depuis l’écran Tâches ou avec `/tache Préparer mes affaires` dans la conversation. Les échanges sont conservés dans `.data/lumos.sqlite3`. Les tâches internes ne déclenchent aucune notification.

Windows : exécute `scripts/setup.ps1`, puis `.venv\Scripts\python.exe scripts\run.py` et `.venv\Scripts\python.exe scripts\owner_code.py`. Commandes fournies, non testées sur Windows.

## Conversation réelle et voix

Voir [le guide complet](docs/SETUP.md) pour Ollama ou llama.cpp, les modèles gratuits, la transcription locale, les voix françaises du système et les limites de sécurité. Il faut installer les modèles avant la première conversation ; l’application ne fabrique pas de réponse en leur absence.

## Vérifications

```sh
.venv/bin/python -m pytest -q
node tests/voice_state_test.mjs
```

Parcours navigateur optionnel : [docs/TEST_REPORT.md](docs/TEST_REPORT.md). Les doubles de modèle existent uniquement dans les tests. [État des capacités](docs/STATUS.md) · [Architecture](docs/ARCHITECTURE.md) · [Décisions](docs/DECISIONS.md).
