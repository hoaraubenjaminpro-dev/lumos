# Rapport de vérification — 26 octobre 2026

## Environnement exécuté

Linux x86_64, Python 3.12.14, Node 24.19.0, Chromium système. 5 threads CPU, ~33 Gio RAM observés ; aucune identification du matériel personnel de Chris. Versions Python dans `requirements.lock`, automate navigateur optionnel dans `requirements-browser.lock`.

## Résultats

- `python -m pytest -q` : **30 tests passés**, aucun échec ni test ignoré. Un avertissement de dépréciation Starlette/AnyIO, sans échec.
- `node tests/voice_state_test.mjs` : contrôles d’automate passés (micro initialement fermé, file par segments, préfixe prononcé, interruption, rejet des callbacks obsolètes). Double de synthèse, pas de son réel.
- `node --check apps/web/app.js` et `voice.js` : syntaxe valide.
- `python -m pip check` : graphe installé cohérent ; imports faster-whisper/CTranslate2/PyAV vérifiés après ajout explicite de `requests`, requis à l’exécution par faster-whisper 1.1.1.
- `tests/browser_smoke.py` : connexion, vraie tâche en base et achèvement, carnet mémoire, journal/preuve, erreur de modèle absent, téléchargement d’export vérifié, navigation et absence de débordement mobile. Aucune erreur JavaScript après correction d’une erreur de navigation repérée par le premier essai.
- Démarrage FastAPI et requête HTTP réelle `/health` : 200, état `ok`.
- Binaire Ollama 0.40.11 : SHA-256 officiel vérifié. Démarrage temporaire avec cloud désactivé observé ; le lancement normal est bloqué par `~/.ollama` sur système de fichiers en lecture seule. Aucun contournement de HOME ne figure dans les scripts livrés. Alternative llama.cpp `--version`/`--help` exécutée ; modèle absent détecté explicitement.
- Premières requêtes modèle Hugging Face et manifeste du registre Ollama : refus proxy HTTP 403. Téléchargements Hugging Face réussis ensuite ; modèles verrouillés et SHA-256 contrôlés. Aucun certificat ni checksum désactivé.
- Modèle réel : `python -m tests.local_model_smoke`, réponse observée « La capitale de la France est Paris. », persistance et export vérifiés, aucune tâche non demandée.
- Transcription réelle : `python -m tests.local_speech_smoke` avec fixture française générée par eSpeak NG (dépendance optionnelle de test). Le profil base échouait sur « affaires » ; correction avec small + beam size 5 : « Bonjour l’humour. Je voudrais préparer mes affaires pour demain. ». Essai froid observé : 3,15 s, échantillon unique. Nom propre encore incorrect ; aucune qualification microphone ni sortie audio.
- Parcours Chromium exécuté aussi avec `LUMOS_SMOKE_REAL_MODEL=1` : vraie réponse « Paris » visible et exportée.

Les tests couvrent authentification/CSRF/origine/hôte, limitation des tentatives, idempotence et versions, commandes explicites/négation/document hostile sans action, messages sans duplication, modèle absent sans fausse réponse, texte prononcé, correction/oubli mémoire, redémarrage/révocation et restauration fidèle, rollback d’archive invalide, quatre formulations de faux succès, destinations locales, annulation de génération, interruption de lecture, limite d’upload, récupération après interruption du processus et protocoles Ollama/llama.cpp.

Les tests de modèle utilisent des fixtures strictement réservées aux tests. Le filtrage des faux succès est heuristique : ces cas passés ne garantissent pas toutes les formulations. Les modèles n’ont aucune capacité d’exécution dans cette version.

## Reproduire le parcours navigateur

Installer les dépendances optionnelles avec `python -m pip install -r requirements-browser.lock` et disposer de Chromium. Dans deux terminaux, depuis la racine du dépôt :

```sh
# Profil dédié neuf ; ne pas utiliser les données personnelles pour ce test.
LUMOS_DATA_DIR=/tmp/lumos-browser-test .venv/bin/python scripts/run.py
```

```sh
LUMOS_DATA_DIR=/tmp/lumos-browser-test .venv/bin/python tests/browser_smoke.py
```

Le test nécessite que le modèle soit absent (il vérifie ce diagnostic), crée une tâche et un souvenir de fixture dans ce profil dédié. Utiliser un nouveau dossier à chaque exécution. Les captures sont écrites dans `/tmp`, sans code d’authentification.

## Recette produit non exécutée

T01–T02, T04–T05, T08–T11, T14–T19, T21, T23–T26, T28–T29 : non qualifiés dans leur scénario complet. En particulier : micro/synthèse réels, dix tours français, dates/récurrences, performances, coupures et caches persistants, protocoles natifs, multi-appareil, disque plein, tests iPhone verrouillé/silencieux. T03/T06/T07/T12/T13/T17/T20/T22/T27/T30 ont une couverture partielle dans le périmètre interne ; ne pas assimiler celle-ci à la validation native ou vocale du cahier des charges.

## Vérifications réelles optionnelles

Moteur llama.cpp démarré et modèles présents :

```sh
.venv/bin/python -m tests.local_model_smoke
.venv/bin/python -m pip install -r requirements-speech-test.lock
.venv/bin/python -m tests.local_speech_smoke
```

Pour le parcours navigateur réel, démarrer Lumos dans un profil neuf avec `LUMOS_BACKEND=llamacpp` et `LUMOS_WHISPER_DIR` défini, puis lancer le smoke navigateur avec ces mêmes variables de profil et `LUMOS_SMOKE_REAL_MODEL=1`. eSpeak NG est utilisé uniquement comme générateur de fixture, pas comme voix du produit ; sa licence et ses notices sont dans la wheel optionnelle installée.

## Paquet Windows — vérification supplémentaire

- 30 tests passent : notamment jeton navigateur authentifié, usage unique, expiration, refus d’origine étrangère, refus d’archives modifiées, chemins ZIP traversants et exclusion effective des secrets/données du paquet.
- `python -m tests.desktop_smoke` : démarrage réel d’un modèle et d’un serveur dédiés, ouverture Chromium avec authentification automatique, suppression du fragment de l’URL, réponse française réelle, second lancement sans conflit et arrêt des deux services possédés. Exécuté sur Linux, sans toucher au profil personnel.
- Toutes les 41 dépendances de `requirements.lock` ont été téléchargées sous forme de roues compatibles Windows x64/Python 3.12 ; cela vérifie leur disponibilité, pas l’import natif sur Windows.
- uv Windows 0.13.5 et llama.cpp b11669 CPU x64 : archives officielles téléchargées et SHA-256 vérifiés avec leurs sommes officielles. Importations PE inspectées ; uv ne dépend pas d’un runtime VC supplémentaire. Le moteur dépend de VC++, d’où la vérification/installation Microsoft conditionnelle.
- Le script PowerShell et la commande intégrée au CMD sont analysés sans erreur par le parseur officiel PowerShell 7.6.9 sous Linux. Windows PowerShell 5.1, le Job Object, l’installateur VC++, le raccourci Bureau et le lancement complet sous Windows ne sont pas exécutés ici.
- La nouvelle session vocale ne se ferme plus lors de la création automatique de sa première conversation ; les essais audio matériels restent nécessaires.

Le paquet contient le code et le lanceur. Il ne contient ni environnement virtuel, modèle, fichier propriétaire, historique, export personnel ni jeton de connexion. La première utilisation télécharge et vérifie les composants. Une coupure de réseau peut donc empêcher cette première préparation ; aucun repli payant ou réponse factice ne remplace une erreur.

## Correction après le premier essai Windows

Le premier essai réel de l’utilisateur a atteint l’étape 2 puis échoué : pytest et tqdm réclament `colorama` uniquement sous Windows. La liste verrouillée avait été produite sous Linux. Vérifier la présence des roues Windows ne suffisait pas : pip évaluait certains marqueurs avec l’environnement hôte. Le problème a été reproduit depuis les métadonnées réelles des roues, avec un environnement cible Windows/Python 3.12 explicite.

Correction : `colorama==0.4.6; sys_platform == 'win32'` dans les dépendances et le verrou. Le contrôle `python scripts/check_windows_dependencies.py --wheels <dossier-des-wheels-Windows>` vérifie désormais toutes les dépendances transitives actives : 41 paquets, aucune dépendance manquante ni version incompatible. Un test de régression couvre spécifiquement les deux marqueurs Windows de pytest et tqdm. Suite : 30 tests passent. La fermeture des dépendances est corrigée ; les étapes suivantes du lancement natif Windows restent à observer sur le PC.
