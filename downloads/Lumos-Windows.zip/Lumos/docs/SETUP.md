# Installation personnelle et cloud

## 0. Windows — démarrage simplifié

Extraire entièrement le paquet et double-cliquer sur `Demarrer Lumos.cmd` ; aucune commande ni installation manuelle de Python n’est nécessaire. Ne pas ouvrir le lanceur à l’intérieur de l’archive. Le téléchargement initial utilise GitHub, PyPI et Hugging Face, avec TLS et empreintes vérifiés. Le fichier `packages/windows/runtime.json` fixe uv 0.13.5, Python 3.12.14 et llama.cpp b11669 CPU x64. Les 40 dépendances Python épinglées ont des wheels Windows disponibles, téléchargées pour contrôle.

Le lanceur prépare `.venv` et `.data`, vérifie les modèles et ouvre le navigateur. L’authentification passe par un jeton de 90 secondes à usage unique, retiré immédiatement de la barre d’adresse ; le code propriétaire permanent n’est jamais placé dans une URL. Le double-clic suivant réutilise les services existants de ce profil. Les processus inconnus ne sont pas arrêtés. Un Job Object Windows doit arrêter les services détenus si la fenêtre du lanceur est fermée ; cette branche native reste non testée.

Si le runtime Visual C++ manque, son installateur est téléchargé depuis Microsoft, sa signature Authenticode valide et son éditeur sont vérifiés avant exécution. Windows peut demander l’autorisation système. Aucun changement global de politique PowerShell ni désactivation de certificat, antivirus ou vérification n’est prévu. Les mises à jour de composants Microsoft suivent l’installateur signé actuel, les autres artefacts ont des révisions fixes.

L’installation partiellement terminée reprend au prochain lancement ; un marqueur de dépendances n’est enregistré qu’après succès. Une archive en cache altérée est refusée. Les données personnelles ne font jamais partie du paquet construit. Le superviseur, l’ouverture automatique, la réponse IA et l’arrêt des services ont été testés sur Linux avec un profil temporaire ; ce n’est pas une preuve d’exécution native sur Windows.

## 1. Première ouverture sans modèle

Python 3.12 et un navigateur récent. Depuis la racine :

```sh
bash scripts/setup.sh
.venv/bin/python scripts/run.py
```

Un second terminal : `.venv/bin/python scripts/owner_code.py`. Ouvrir le serveur de cette machine sur le port 8000 et saisir le code affiché dans le terminal. Le serveur écoute exclusivement loopback ; ne pas utiliser `0.0.0.0`. Aucun lien public ni aperçu distant n’est configuré.

Fonctionnent sans modèle : tâches, historique, carnet mémoire et export. Sans modèle, la conversation affiche une erreur explicite et conserve le message. Le micro est fermé tant que tu ne l’actives pas. Pas de clé API ni d’abonnement nécessaire.

Windows : `scripts/setup.ps1`, puis `.venv\Scripts\python.exe scripts\run.py` et `.venv\Scripts\python.exe scripts\owner_code.py`. macOS : mêmes commandes shell avec Python 3.12. Ces plateformes ne sont pas testées dans cette livraison. `scripts/diagnose.py` relève uniquement OS, architecture, threads, mémoire Linux, espace disque et présence d’outils ; aucun document personnel.

## 2. Modèle local — ordinateur personnel

Installer Ollama depuis sa source officielle (https://github.com/ollama/ollama/releases ou https://ollama.com/download), consulter sa licence et la compatibilité de la machine. Ne pas copier un cookie ChatGPT/Claude ni activer une offre cloud.

Dans le terminal du moteur :

```sh
export OLLAMA_NO_CLOUD=1
export OLLAMA_HOST=127.0.0.1:11434
ollama serve
```

Dans un autre terminal :

```sh
ollama pull qwen2.5:1.5b
ollama list
```

Puis démarrer le serveur Lumos. Valeurs par défaut : `LUMOS_BACKEND=ollama`, `LUMOS_MODEL=qwen2.5:1.5b`, `LUMOS_OLLAMA_URL=http://127.0.0.1:11434`. Le nom de variable URL est partagé par les deux adaptateurs pour compatibilité. Les fichiers `.env` ne sont pas chargés automatiquement : exporter les variables dans le terminal ou utiliser les paramètres d’environnement. Sur PowerShell : `$env:OLLAMA_NO_CLOUD='1'`, puis `ollama serve` ; les autres variables suivent la même syntaxe.

Qwen2.5 1.5B Instruct est un candidat léger, pas une garantie de qualité. Profil quantifié Q4_K_M ~1,1 Go, mémoire de travail supplémentaire et contexte 4096. Un modèle plus grand peut être choisi après diagnostic matériel et essais français. Vérifier qu’une réponse est réelle dans la conversation, sans commande `/tache`, puis redémarrer et vérifier l’historique.

## 3. Alternative Linux cloud — llama.cpp

La distribution officielle Ollama installée contient `llama-server`. Cette voie ne requiert pas le dossier `~/.ollama`, qui est en lecture seule dans la machine cloud actuelle.

```sh
bash scripts/install_ollama_linux.sh
.venv/bin/python scripts/download_models.py
bash scripts/start_llama.sh
```

Dans un second terminal :

```sh
export LUMOS_BACKEND=llamacpp
export LUMOS_WHISPER_DIR="$PWD/.data/models/whisper-small"
.venv/bin/python scripts/run.py
```

Le moteur écoute loopback sur le port 8081, alias `qwen2.5:1.5b`, 4 threads CPU, contexte 4096, sans GPU. Son script vérifie la présence du modèle avant lancement. Le binaire, installé dans `.data/tools`, a été testé pour sa version/aide ; le démarrage avec le modèle Qwen installé et une réponse réelle via Lumos ont été vérifiés.

`install_ollama_linux.sh` vérifie le SHA-256 officiel de la release 0.40.11 avant extraction, sans désactiver TLS. Téléchargement ~1,5 Go ; seules les bibliothèques CPU sont extraites. Le fichier compressé peut être conservé comme cache de réinstallation ; ne pas l’ajouter à Git. Prérequis shell : curl, tar avec zstd, sha256sum, Linux x86_64. Sur un ordinateur personnel classique, préférer Ollama installé normalement.

### Réseau : blocage initial résolu pour Hugging Face

Les premières requêtes Hugging Face et registre Ollama ont reçu HTTP 403. Après les mises à jour du brouillon, les téléchargements Hugging Face ont effectivement réussi. Le registre Ollama n’a pas été requalifié ; llama.cpp permet de s’en passer. Domaines nécessaires enregistrés dans le brouillon : `huggingface.co`, `*.huggingface.co`, `*.hf.co`, `registry.ollama.ai`. Le téléchargement de binaires via GitHub est déjà autorisé par les préréglages. Une éventuelle redirection CDN du registre Ollama doit être diagnostiquée après accès au manifeste ; ne pas autoriser arbitrairement tout Internet.

Dans les paramètres de l’environnement, revoir/enregistrer ces changements puis publier. L’enregistrement du brouillon ne prouve pas à lui seul une application de la politique ni une publication ; les téléchargements réussis établissent ici la connectivité effective. Après changement effectif, relancer les téléchargements et les vérifications. Si le proxy reste bloqué, terminer le diagnostic plutôt que désactiver la validation TLS.

## 4. Conversation vocale locale

Télécharger explicitement le modèle de transcription multilingue :

```sh
.venv/bin/python scripts/download_speech.py
export LUMOS_WHISPER_DIR="$PWD/.data/models/whisper-small"
```

Redémarrer Lumos en conservant cette variable. Installer une voix française dans les réglages vocaux du système ; le navigateur doit la signaler `localService=true`. La liste est visible dans Réglages & capacités. Si aucune voix locale n’est détectée, l’application refuse de lancer la voix et explique le besoin. Elle n’utilise pas de voix distante comme repli.

Activer « Parler », autoriser le micro, parler normalement puis laisser environ une seconde de silence. Chaque intervention est transcrite localement, envoyée dans la conversation existante et lue par phrases. « Arrêter » coupe la sortie et la génération ; le bouton « Fermer le micro » termine la session. Le passage à un autre onglet/écran ferme le micro par précaution.

**À qualifier sur matériel :** détection de début de parole sans pré-buffer (première syllabe potentiellement perdue), hésitations/pauses, seuils micro, négations, capture continue, audio Bluetooth, écho et interruption vocale. Commencer au casque ; les seuils fixes ne garantissent pas le fonctionnement haut-parleur. La transcription est par tour complet, pas incrémentale. La transcription d’une phrase française synthétique est vérifiée avec Whisper small (3,15 s à froid sur cet essai). Le nom « Lumos » y est mal reconnu. Ni iPhone ni dix tours audio ni les latences cibles ne sont vérifiés. Pas d’écoute permanente en arrière-plan. Ce n’est pas encore la phase A vocale acceptée.

Les alarmes, calendriers Apple, mails et rappels externes sont indisponibles. Pour une tâche interne, le formulaire et la commande `/tache titre` sont les parcours vérifiés ; la commande textuelle exacte `crée une tâche : titre` est aussi reconnue. Les demandes de rappel avec date ne sont pas exécutées ni programmées.

## 5. Données, restauration et révocation locale

Réglages → Exporter : JSON version 1, conversations/messages, tâches, actions et carnet mémoire ; aucun code de connexion ni configuration d’accès. Export en clair : protéger le fichier. Ni chiffrement applicatif ni sauvegarde chiffrée ne sont revendiqués.

Pour restaurer : arrêter le serveur ; démarrer un nouveau profil avec `LUMOS_DATA_DIR=/chemin/vers/un/dossier-neuf`, afficher son code via `owner_code.py` avec la même variable, se connecter puis choisir l’export dans Réglages. La restauration est atomique et refuse un profil non vide. Un souvenir supprimé avant l’export n’est pas réintroduit ; **un export ancien peut encore le contenir**. Choisir une archive récente et vérifier les souvenirs après restauration. Pas de fusion de profils ni de registre d’effacement multi-appareil dans cette tranche.

Déconnexion révoque la session courante. Un redémarrage révoque toutes les sessions. Pour changer le code propriétaire, arrêter le serveur, retirer uniquement le fichier `owner-code` du dossier de données puis redémarrer ; le code est recréé aléatoirement, les autres données conservées. Aucun appairage ou effacement à distance d’appareil n’est fourni.

Pour une copie SQLite manuelle : arrêter le serveur avant de copier **le dossier de données complet**, pas une base ouverte partagée dans un dossier cloud. Avant toute future migration, sauvegarder ce dossier. Ne pas lancer deux instances de Lumos sur le même profil. La migration initiale ne fait pas de transformation destructive ; les migrations futures doivent prévoir sauvegarde et retour arrière.

## 6. Licences et plateformes natives

Licences et versions installées : `docs/DEPENDENCY_LICENSES.json`. Ollama/llama.cpp et leurs bibliothèques : notices exactes conservées sous `.data/tools/lib/ollama/*LICENSE*` (artefacts locaux ignorés par Git). Qwen2.5 1.5B : Apache-2.0 ; Whisper : MIT ; vérifier et archiver les fichiers du modèle effectivement téléchargé avant toute redistribution. La voix système dépend de l’OS : aucune voix n’est redistribuée. Le code de Lumos n’a pas reçu de licence de publication sans choix du propriétaire.

Les intégrations Apple nécessitent un Mac, Xcode/SDK compatibles et un appareil physique. Aucune application iOS n’est fournie ici. Une signature Personal Team gratuite est temporaire (conditions Apple à recontrôler, typiquement sept jours), et n’autorise pas à promettre des alarmes fiables ou une installation permanente. Le guide de réinstallation et les tests EventKit/AlarmKit seront livrés avec le client natif.

## Artefacts verrouillés

Les scripts de téléchargement fixent les révisions et vérifient SHA-256. Qwen : `91cad51170dc346986eccefdc2dd33a9da36ead9` ; Whisper small : `536b0662742c02347bc0e980a01041f333bce120`. Empreintes dans `docs/MODELS.json`. Licence et fiche Qwen conservées dans `.data/models/qwen-notices` ; fiche de Whisper sous `.data/models/whisper-small/README.md`. Les notices des wheels restent dans leurs dossiers `.dist-info` de l’environnement virtuel.
