# Décisions

## 2026-10-26 — Première livraison web avant Flutter

Motif : dépôt initial vide, machine Linux sans Xcode et priorité à une tranche exécutable. Impact : texte, tâches et stockage utilisables sur navigateur ; aucune capacité native Apple revendiquée. Flutter et Swift restent des lots ultérieurs.

## 2026-10-26 — SQLite et API locale authentifiée

Motif : un propriétaire, installation sans service tiers. Impact : transactions atomiques, base portative ; pas encore de synchronisation ni accès distant. Aucun dossier personnel scanné. Aucune donnée biographique d’exemple importée.

## 2026-10-26 — Modèles séparés et deux adaptateurs

Ollama est la voie personnelle principale, cloud désactivé. Sa version Linux 0.40.11 a été téléchargée depuis la release officielle et vérifiée avec le SHA-256 de cette release. La distribution fournit également llama.cpp `0.7.0-dev`, commit `9ff0d7e90`, retenu comme alternative locale lorsque le dossier utilisateur d’Ollama est en lecture seule. Impact : `LUMOS_BACKEND=llamacpp` fonctionne sans écrire dans le dossier utilisateur d’Ollama. Le modèle Qwen et Whisper small ont ensuite été installés et contrôlés ; réponse texte réelle et transcription synthétique vérifiées. La latence conversationnelle complète reste inconnue.

## 2026-10-26 — Profil de départ, non promesse de qualité

Candidat Qwen2.5 1.5B Instruct Q4_K_M (~1,1 Go), contexte 4096, 4 threads CPU. Modèle français de départ, à remplacer si la qualité est insuffisante ; pas qualifié comme meilleur modèle disponible. Matériel cloud observé : 5 threads, ~33 Gio RAM, aucun GPU identifié par le moteur. Ce ne sont pas les caractéristiques du PC ou du Mac de Chris. Profil STT : faster-whisper small multilingue (~500 Mo), CPU int8. Il faut mesurer les dix tours et la qualité française sur la machine personnelle.

## 2026-10-26 — Pas d’actions libres du modèle

Motif : éviter faux succès et mutations non sollicitées. Impact : création interne par formulaire ou commande explicite ; négations et documents ne déclenchent pas d’outils. Langage naturel des dates, rappels récurrents et planification à implémenter séparément.

## 2026-10-26 — Voix locale, validation matérielle distincte

Motif : pas d’API payante obligatoire ni reconnaissance cloud implicite. Impact : transcription serveur locale, voix française système locale seulement. VAD par tours et synthèse par phrases ; pas de transcription incrémentale ni de VAD neuronal client. Casque conseillé, pas d’écoute en arrière-plan, session fermée quand la page devient invisible. Ce prototype n’est pas encore une conversation vocale qualifiée.

## 2026-10-26 — Mémoire explicite sans récupération automatique

Motif : ne pas injecter automatiquement des informations non qualifiées et ne pas prétendre implémenter une recherche mémorielle. Impact : carnet consultable/corrigeable/supprimable, sans contexte IA automatique. Effacement physique en profil unique ; tombstones requis avant synchronisation future. Restauration autorisée seulement dans un profil vierge ; un ancien export peut encore contenir un élément supprimé et doit être choisi avec prudence.

## 2026-10-26 — Transcription small après échec mesuré de base

Le profil base multilingue a mal reconnu la phrase française synthétique « Je voudrais préparer mes affaires pour demain ». Le profil small, beam size 5, restitue cette demande mais confond encore « Lumos » avec « l’humour ». Impact : téléchargement ~500 Mo et calcul CPU plus important ; 3,15 s observées sur un seul tour synthétique à froid, sans garantie de percentile ni validation de micro.

## 2026-10-26 — Paquet Windows à double-clic

L’utilisateur choisit Windows et veut essayer sans préparer de terminal. Le paquet source privé amorce uv vérifié, Python géré localement, les dépendances verrouillées et llama.cpp CPU. Les modèles sont contrôlés et réutilisés hors ligne. Le navigateur reçoit un jeton éphémère de 90 s, consommé une fois, issu d’une authentification locale du lanceur ; aucun code permanent dans l’URL. Les services sont surveillés et arrêtés uniquement s’ils appartiennent à ce lanceur. Aucun démarrage automatique de l’ordinateur, service Windows persistant ni exposition réseau n’est ajouté. La branche Windows native reste à tester sur appareil ; les preuves Linux et les contrôles d’artefacts sont distingués.
