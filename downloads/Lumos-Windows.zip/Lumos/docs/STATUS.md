# Statut — 26 octobre 2026

Première tranche exécutable ; **phase A non entièrement validée**. Pas de données factices dans l’application. Aucun push GitHub ni publication d’environnement effectué.

| Capacité | Réalisé | Preuve / limite |
|---|---|---|
| Interface française responsive | Développé, testé navigateur | Chromium desktop 1440 px et viewport 390 px ; pas test iPhone |
| Authentification locale | Testé automatiquement et navigateur | Code local, session, rejet origine/hôte, limitation de tentatives |
| Historique et reprise serveur | Testé automatiquement | SQLite, redémarrage et révocation des anciennes sessions |
| Tâches internes, journal | Testé automatiquement et navigateur | Création réelle, preuve, idempotence, version concurrente |
| Export / restauration | Testé automatiquement, export navigateur | Profil vierge, rollback sur archive invalide, absence de doublon |
| Carnet mémoire | Testé automatiquement et navigateur | Correction, oubli, provenance ; pas de récupération dans le modèle |
| Ollama / llama.cpp | Adaptateurs développés, protocoles testés avec doubles | Qwen 1.5B Q4 installé, hash vérifié ; réponse locale réelle via llama.cpp et Chromium |
| Texte avec une IA réelle | Testé automatiquement et navigateur | Réponse française réelle, conservation et export ; qualité générale non évaluée |
| Micro/VAD/transcription locale | Développé, dépendances importées | Whisper small installé ; transcription réelle de français synthétique, micro physique non testé |
| Synthèse et interruption | Développé, automate testé | Segments prononcés, arrêt et génération obsolète testés sans audio physique |
| Dix tours de conversation vocale | Non vérifié | Modèles, voix et micro réels requis ; latence non mesurée |
| Windows/macOS | Instructions fournies, non testées | Linux uniquement exécuté |
| Cache hors ligne et synchronisation | Spécifié | Contenu affiché conservé pendant coupure, aucun cache persistant promis |
| Projets, documents/OCR, routines | Spécifié | Non implémenté |
| Mail, calendriers/rappels Apple, alarmes iPhone | Non pris en charge | Aucun faux bouton ni confirmation native |
| Appairage / révocation par appareil | Spécifié | Déconnexion et rotation globale locales seulement |
| Mode privé et chiffrement applicatif | Non implémenté | Aucun réglage qui prétend le contraire |

## Dépendances restantes et suite concrète

1. Revoir/enregistrer les scripts et règles réseau dans les paramètres, puis publier l’environnement. Les modèles sont téléchargés dans cette instance ; la restauration dans une nouvelle tâche n’a pas encore été vérifiée.
2. Sur le PC/Mac personnel, installer une voix française locale et tester dix tours : négations, changements texte/voix, interruption, casque puis haut-parleur. Le nom « Lumos » est encore mal transcrit dans la fixture synthétique.
3. Mesurer et améliorer VAD/pré-buffer, transcription incrémentale et latences ; puis mémoire contextualisée, projets et appairage.
4. Apple nécessite Mac/Xcode et appareil physique ; aucun réveil ni rappel Apple n’est promis dans cette tranche.

## Configuration cloud enregistrée

`install_script` et `start_skill` ont été enregistrés dans le brouillon, ainsi que les règles réseau mentionnées dans SETUP. Le script complet d’installation a été exécuté avec succès, y compris le contrôle du binaire et des deux modèles. Le moteur llama.cpp et le serveur Lumos ont été redémarrés dans cette instance ; le profil principal est vierge de fixtures et les capacités texte/transcription sont disponibles. La validation des paramètres et la publication restent à effectuer dans l’interface du produit ; aucune restauration de nouvelle tâche n’est revendiquée.

## Démarrage Windows simplifié

Paquet privé Windows avec lanceur à double-clic développé, authentification navigateur automatique, Python et dépendances locaux, téléchargement vérifié des modèles, supervision et réutilisation des services. 30 tests passent ; parcours complet du superviseur testé sur Linux avec une vraie réponse locale. Disponibilité des roues Windows et empreintes des binaires vérifiées. Exécution sur un PC Windows, permissions éventuelles Microsoft et voix sur appareil restent non vérifiées. Le fichier `LIRE-MOI-WINDOWS.txt` explique uniquement extraction, double-clic et arrêt.
