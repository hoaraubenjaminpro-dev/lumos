# Architecture — tranche 0.1

Le serveur FastAPI sert une interface HTML/CSS/JavaScript sans dépendance front-end ni ressource distante. Python 3.12 ; dépendances transitives épinglées dans `requirements.lock`. `services/lumos_server/storage.py` centralise SQLite, les transactions et la migration initiale `user_version=1`.

## Frontières

- Interface : saisie, rendu via `textContent` (jamais HTML de modèle), capture micro après consentement, VAD par niveau audio, lecture par segments, interruption et suppression des générations obsolètes.
- Serveur : identité locale, validation Pydantic, historique, annulation, tâches internes, actions et preuves, carnet mémoire, export/restauration atomique.
- Moteur : adaptateurs Ollama et llama.cpp, HTTP loopback seulement, proxy désactivé pour les appels d’inférence, aucun repli distant. Modèles séparés du code. Ollama doit être démarré avec `OLLAMA_NO_CLOUD=1`.
- Voix : MediaRecorder (codec négocié), fin de tour après ~950 ms de silence ; envoi HTTP du tour complet vers faster-whisper CPU/int8. Synthèse `speechSynthesis` avec `localService=true` et langue française obligatoires. Aucune Web Speech Recognition ni reconnaissance cloud du navigateur.

## Fiabilité

Les commandes `/tache titre` et `crée une tâche : titre` sont interprétées uniquement si elles constituent le message entier. Le modèle n’exécute aucun outil. Les tâches et leur preuve d’action sont écrites dans une même transaction, avec clé d’idempotence unique et conflit si la même clé change de contenu. Les modifications de tâches et souvenirs exigent `base_version`.

Les réponses du modèle sont reçues en flux interne puis contrôlées avant présentation complète. Le garde-fou textuel repère certaines affirmations de succès ; c’est une heuristique, pas une garantie sémantique. Les preuves et effets métiers viennent exclusivement des exécuteurs. Il n’y a pas de diffusion token par token au client dans cette tranche, donc la latence vocale cible n’est pas atteinte ou mesurée.

Le flux client HTTP NDJSON porte identifiants d’événement, de génération et de message, séquence et date UTC. L’interruption coupe la lecture locale immédiatement, invalide les callbacks puis annule le traitement. Le contenu généré et le préfixe prononcé sont stockés séparément ; seuls les segments entièrement achevés sont attestés par le navigateur. Une réponse interrompue ne réintroduit que son préfixe prononcé dans le prochain contexte. Sans accusé audio, rien n’est supposé entendu.

## Sécurité de cette tranche

Accès au serveur limité à loopback ; validation Host et Origin ; cookie HttpOnly SameSite Strict (Secure en HTTPS), session 12 heures, code local aléatoire, limitation de tentatives, en-tête explicite requis pour mutations et CSP sans ressources tierces. Déconnexion/rédémarrage révoquent les sessions. Le navigateur et le moteur restent deux composants distincts ; le port du moteur ne doit jamais être exposé sur Internet.

La base et les exports ne sont pas chiffrés par l’application. Protéger le disque avec les mécanismes du système. Le code de connexion est un fichier local en mode 0600 sous un dossier 0700. Pas de journal applicatif de contenu ni d’enregistrement audio durable ; le parseur multipart peut utiliser un fichier temporaire, supprimé à la fermeture de la requête. Les durées et volumes audio sont bornés, le décodage s’arrête après 31 s. Une analyse hostile des codecs reste un risque à traiter par isolation pour un déploiement réseau.

## Extensions prévues, non implémentées

Appairage par appareil et clés révocables, cache et synchronisation avec tombstones, projets, recherche mémoire contrôlée, propositions d’outils et validations liées au contenu, canal WebSocket/WebRTC, connecteurs natifs Swift/EventKit/AlarmKit et client Flutter. Aucun endpoint fictif de ces fonctionnalités n’est exposé. Le contrat des routes présentes est versionné dans `packages/contracts/openapi.json` ; évolution avec migration et tests.
