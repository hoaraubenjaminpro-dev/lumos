import asyncio
import hmac
import hashlib
import io
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time
from urllib.parse import urlsplit
from uuid import UUID

from fastapi import FastAPI, File, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, ConfigDict

from .models import Ollama, LlamaCpp, ModelUnavailable
from .storage import Store, now, uid

ROOT = Path(__file__).resolve().parents[2]


class Input(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)


class Login(Input):
    code: str = Field(min_length=1, max_length=200)


class Conversation(Input):
    title: str = Field(default='Nouvelle conversation', min_length=1, max_length=100)


class Message(Input):
    content: str = Field(min_length=1, max_length=8000)
    client_id: UUID


class Task(Input):
    title: str = Field(min_length=1, max_length=300)
    idempotency_key: UUID


class TaskUpdate(Input):
    status: str = Field(pattern='^(open|done)$')
    base_version: int = Field(ge=1)


class Memory(Input):
    content: str = Field(min_length=1, max_length=2000)
    source: str = Field(default='Saisie explicite', min_length=1, max_length=200)


class MemoryUpdate(Memory):
    base_version: int = Field(ge=1)


class Spoken(Input):
    text: str = Field(max_length=6000)


def error(code, message, status=400, retryable=False):
    return JSONResponse({'error': {'code': code, 'message': message,
                                  'retryable': retryable, 'diagnostic_id': uid()}}, status_code=status)


# Model text never drives tools. Explicit commands are anchored, never inferred.
TASK_COMMAND = re.compile(r'^(?:/tache\s+|crée une tâche\s*:\s*)(.{1,300})$', re.I | re.S)
CLAIM = re.compile(r"(?:j['’]ai|nous avons|c['’]est|a été|ont été).{0,60}(?:envoy|créé|programmé|enregistré|supprimé|modifié)|(?:mail|message|rappel|alarme)\s+(?:envoyé|créé|programmé)", re.I)


def safe_response(text):
    if CLAIM.search(text):
        return "Je n’ai exécuté aucune action. Utilise le formulaire Tâches ou /tache suivi du titre pour enregistrer une tâche interne. Les intégrations externes ne sont pas disponibles."
    return text


def create_app(data_dir=None, adapter=None):
    data = Path(data_dir or os.getenv('LUMOS_DATA_DIR', ROOT / '.data')).resolve()
    data.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(data, 0o700)
    code_file = data / 'owner-code'
    if not code_file.exists():
        fd = os.open(code_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as f:
            f.write(secrets.token_urlsafe(24))
    code = code_file.read_text().strip()
    backend = os.getenv('LUMOS_BACKEND', 'ollama')
    if backend not in ('ollama', 'llamacpp'):
        raise ValueError('LUMOS_BACKEND doit être ollama ou llamacpp.')
    url = os.getenv('LUMOS_OLLAMA_URL', 'http://127.0.0.1:11434' if backend == 'ollama' else 'http://127.0.0.1:8081').rstrip('/')
    parsed = urlsplit(url)
    if parsed.scheme != 'http' or parsed.hostname not in ('127.0.0.1', 'localhost', '::1') or parsed.username or parsed.password or parsed.path:
        raise ValueError('LUMOS_OLLAMA_URL doit désigner un serveur HTTP loopback sans chemin.')
    model = os.getenv('LUMOS_MODEL', 'qwen2.5:1.5b')
    if ':' not in model or model.endswith(':cloud') or '/' in model:
        raise ValueError('Utiliser le nom exact d’un modèle local avec son tag, sans fournisseur cloud.')
    store = Store(data / 'lumos.sqlite3')
    engine = adapter or (Ollama if backend == 'ollama' else LlamaCpp)(url, model)
    app = FastAPI(title='Lumos', version='0.1.0', docs_url=None, redoc_url=None, openapi_url=None)
    app.state.store = store
    app.state.engine = engine
    app.state.code = code
    sessions, attempts, active = {}, {}, {}
    browser_launches = {}
    speech_lock = threading.Lock()
    whisper = None
    whisper_path = os.getenv('LUMOS_WHISPER_DIR', '')

    @app.middleware('http')
    async def security(request, call_next):
        host = request.headers.get('host', '').split(':')[0]
        if host not in ('127.0.0.1', 'localhost', '[', 'testserver'):
            return error('permission_denied', 'Hôte non autorisé : accès local uniquement.', 403)
        origin = request.headers.get('origin')
        if origin and origin != str(request.base_url).rstrip('/'):
            return error('permission_denied', 'Origine refusée.', 403)
        if request.method in ('POST', 'PATCH'):
            try:
                length = int(request.headers.get('content-length', '-1'))
            except ValueError:
                length = -1
            if length < 0:
                return error('invalid_input', 'La taille de la requête est requise.', 411)
            limit = 9 * 1024 * 1024 if request.url.path == '/v1/audio/transcribe' else 11 * 1024 * 1024
            if length > limit:
                return error('file_too_large', 'La requête dépasse la taille autorisée.', 413)
        if request.url.path.startswith('/v1/'):
            token = request.cookies.get('lumos_session', '')
            if sessions.get(token, 0) < time.monotonic():
                return error('permission_denied', 'Connecte cet appareil avec le code local.', 401)
            if request.method != 'GET' and request.headers.get('x-lumos-request') != '1':
                return error('permission_denied', 'Requête non autorisée.', 403)
        try:
            response = await call_next(request)
        except sqlite3.Error:
            return error('storage_unavailable', 'Écriture impossible. Vérifie le stockage ; les données existantes sont conservées.', 507)
        response.headers.update({
            'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
            'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; media-src 'self' blob:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
            'Permissions-Policy': 'microphone=(self), camera=(), geolocation=()',
            'Cache-Control': 'no-store',
        })
        return response

    @app.exception_handler(RequestValidationError)
    async def invalid_input(request, exc):
        return error('invalid_input', 'Les données sont incomplètes ou invalides.', 422)

    @app.get('/health')
    async def health():
        return {'status': 'ok', 'version': '0.1.0'}

    def authenticated_response(request):
        token = secrets.token_urlsafe(32)
        sessions[token] = time.monotonic() + 12 * 3600
        for old in list(sessions):
            if sessions[old] < time.monotonic():
                sessions.pop(old, None)
        if len(sessions) > 32:
            sessions.pop(next(iter(sessions)))
        response = JSONResponse({'status': 'authenticated'})
        response.set_cookie('lumos_session', token, httponly=True, samesite='strict',
                            secure=request.url.scheme == 'https', max_age=43200)
        return response

    @app.post('/v1/browser-launch')
    async def browser_launch():
        # The desktop launcher authenticates first using its local owner file.
        for token in list(browser_launches):
            if browser_launches[token] < time.monotonic():
                browser_launches.pop(token, None)
        if len(browser_launches) >= 16:
            browser_launches.pop(next(iter(browser_launches)))
        token = secrets.token_urlsafe(32)
        browser_launches[token] = time.monotonic() + 90
        return {'token': token, 'expires_in': 90}

    @app.post('/auth/bootstrap')
    async def bootstrap(body: Login, request: Request):
        # A short-lived single-use token, never the permanent owner code in a URL.
        expiry = browser_launches.pop(body.code, 0)
        if expiry < time.monotonic():
            return error('permission_denied', 'Ce lancement a expiré. Double-clique à nouveau sur Démarrer Lumos.', 401)
        return authenticated_response(request)

    @app.post('/auth/login')
    async def login(body: Login, request: Request):
        peer = request.client.host
        count, start = attempts.get(peer, (0, time.monotonic()))
        if time.monotonic() - start > 60:
            count, start = 0, time.monotonic()
        if count >= 5:
            return error('rate_limited', 'Attends une minute avant de réessayer.', 429, True)
        if not hmac.compare_digest(body.code.encode(), code.encode()):
            attempts[peer] = (count + 1, start)
            return error('permission_denied', 'Code incorrect.', 401)
        return authenticated_response(request)

    @app.post('/v1/logout')
    async def logout(request: Request):
        sessions.pop(request.cookies.get('lumos_session'), None)
        for turn in active.values():
            turn.set()
        response = JSONResponse({'status': 'signed_out'})
        response.delete_cookie('lumos_session')
        return response

    @app.get('/v1/capabilities')
    async def capabilities():
        return {'local_only': True, 'model': model, 'backend': backend, 'text': await engine.available(),
                'speech_input': bool(whisper_path and Path(whisper_path, 'model.bin').is_file()),
                'speech_output': 'Voix française locale du navigateur requise',
                'tasks': True, 'history': True, 'export_restore': True,
                'apple': 'unsupported_capability', 'pairing': 'unsupported_capability',
                'notifications': 'unsupported_capability'}

    @app.get('/v1/conversations')
    async def conversations():
        return store.all('SELECT * FROM conversations ORDER BY created_at DESC')

    @app.post('/v1/conversations')
    async def conversation(body: Conversation):
        item = {'id': uid(), 'title': body.title, 'created_at': now()}
        with store.connect() as db:
            db.execute('INSERT INTO conversations VALUES(:id,:title,:created_at)', item)
        return item

    @app.get('/v1/conversations/{cid}/messages')
    async def history(cid: UUID):
        return store.all('SELECT * FROM messages WHERE conversation_id=? ORDER BY rowid', (str(cid),))

    @app.post('/v1/conversations/{cid}/interrupt')
    async def interrupt(cid: UUID, message_id: UUID | None = None):
        event = active.get(str(cid))
        if event:
            event.set()
        if message_id:
            with store.connect() as db:
                db.execute("UPDATE messages SET status='interrupted' WHERE id=? AND conversation_id=? AND role='assistant' AND status='complete'",
                           (str(message_id), str(cid)))
        return {'status': 'interrupted' if event else 'idle'}

    @app.post('/v1/messages/{mid}/spoken')
    async def spoken(mid: UUID, body: Spoken):
        with store.connect() as db:
            item = db.execute("SELECT * FROM messages WHERE id=? AND role='assistant'", (str(mid),)).fetchone()
            if not item or not item['content'].startswith(body.text):
                return error('invalid_input', 'Le texte prononcé doit être un préfixe de la réponse.', 422)
            if len(body.text) < len(item['spoken_text']):
                return error('version_conflict', 'Une progression vocale plus récente est déjà enregistrée.', 409)
            db.execute('UPDATE messages SET spoken_text=? WHERE id=?', (body.text, str(mid)))
        return {'status': 'recorded'}

    @app.post('/v1/conversations/{cid}/messages')
    async def message(cid: UUID, body: Message, request: Request):
        cid, client_id = str(cid), str(body.client_id)
        if not store.one('SELECT id FROM conversations WHERE id=?', (cid,)):
            return error('not_found', 'Conversation introuvable.', 404)
        previous = store.one('SELECT * FROM messages WHERE conversation_id=? AND client_id=?', (cid, client_id))
        if previous:
            if previous['content'] != body.content:
                return error('idempotency_conflict', 'Cet identifiant appartient à un autre message.', 409)
            return error('already_recorded', 'Message déjà enregistré. Consulte l’historique.', 409)
        if cid in active:
            return error('turn_running', 'Une réponse est en cours. Arrête-la avant de continuer.', 409, True)
        stop = asyncio.Event()
        active[cid] = stop
        mid, reply_id = uid(), uid()
        try:
            with store.connect() as db:
                db.execute('INSERT INTO messages(id,conversation_id,role,content,status,created_at,client_id) VALUES(?,?,?,?,?,?,?)',
                           (mid, cid, 'user', body.content, 'complete', now(), client_id))
                db.execute('INSERT INTO messages(id,conversation_id,role,content,status,created_at) VALUES(?,?,?,?,?,?)',
                           (reply_id, cid, 'assistant', '', 'generating', now()))
        except BaseException:
            active.pop(cid, None)
            raise

        async def events():
            text, status, sequence = '', 'interrupted', 0
            generation_id = uid()
            def event(kind, **payload):
                nonlocal sequence
                sequence += 1
                return json.dumps({'type': kind, 'event_id': uid(), 'session_id': cid,
                                   'sequence': sequence, 'timestamp': now(), 'generation_id': generation_id,
                                   'message_id': reply_id, **payload}, ensure_ascii=False) + '\n'
            try:
                yield event('session.ready')
                command = TASK_COMMAND.fullmatch(body.content)
                if command:
                    action = store.task(command.group(1).strip(), client_id)
                    text = f"La tâche « {command.group(1).strip()} » est enregistrée dans Lumos. Aucun rappel système n’a été programmé."
                    yield event('action.updated', action=action)
                else:
                    if not await engine.available():
                        raise ModelUnavailable()
                    context = []
                    for m in store.all("SELECT * FROM messages WHERE conversation_id=? AND id!=? ORDER BY rowid", (cid, reply_id)):
                        if m['role'] == 'user':
                            context.append({'role': 'user', 'content': m['content']})
                        elif m['status'] == 'complete':
                            context.append({'role': 'assistant', 'content': m['content']})
                        elif m['spoken_text']:
                            context.append({'role': 'assistant', 'content': m['spoken_text']})
                    # Validate a complete model response before presenting claims of success.
                    draft = ''
                    iterator = engine.stream(context).__aiter__()
                    while True:
                        next_part = asyncio.create_task(anext(iterator))
                        cancelled = asyncio.create_task(stop.wait())
                        try:
                            done, _ = await asyncio.wait({next_part, cancelled}, return_when=asyncio.FIRST_COMPLETED)
                            if cancelled in done or await request.is_disconnected():
                                next_part.cancel()
                                await asyncio.gather(next_part, return_exceptions=True)
                                return
                            try:
                                draft += next_part.result()
                            except StopAsyncIteration:
                                break
                            if len(draft) >= 6000:
                                break
                        finally:
                            cancelled.cancel()
                            await asyncio.gather(cancelled, return_exceptions=True)
                    await iterator.aclose()
                    text = safe_response(draft[:6000].strip())
                    if not text:
                        raise ModelUnavailable()
                if stop.is_set():
                    return
                with store.connect() as db:
                    db.execute('UPDATE messages SET content=? WHERE id=?', (text, reply_id))
                yield event('assistant.text', text=text)
                status = 'complete'
                yield event('turn.complete')
            except ModelUnavailable:
                status = 'failed'
                yield event('error', code='model_unavailable', message='Le modèle local est absent ou injoignable. Tes messages restent enregistrés ; les tâches internes fonctionnent.', retryable=True)
            except asyncio.CancelledError:
                raise
            except Exception:
                status = 'failed'
                yield event('error', code='generation_failed', message='La réponse a échoué. Consulte le diagnostic local.', retryable=True)
            finally:
                with store.connect() as db:
                    db.execute('UPDATE messages SET content=?,status=? WHERE id=?', (text, status, reply_id))
                active.pop(cid, None)
        return StreamingResponse(events(), media_type='application/x-ndjson', headers={'X-Accel-Buffering': 'no'})

    @app.get('/v1/tasks')
    async def tasks():
        return store.all('SELECT * FROM tasks ORDER BY created_at DESC')

    @app.post('/v1/tasks')
    async def create_task(body: Task):
        try:
            return store.task(body.title, str(body.idempotency_key))
        except ValueError:
            return error('idempotency_conflict', 'Cette clé appartient à une autre tâche.', 409)

    @app.patch('/v1/tasks/{tid}')
    async def update_task(tid: UUID, body: TaskUpdate):
        with store.connect() as db:
            changed = db.execute('UPDATE tasks SET status=?,version=version+1 WHERE id=? AND version=?',
                                 (body.status, str(tid), body.base_version)).rowcount
            if not changed:
                return error('version_conflict', 'La tâche a changé. Recharge la liste.', 409)
        return store.one('SELECT * FROM tasks WHERE id=?', (str(tid),))

    @app.get('/v1/actions')
    async def actions():
        return store.all('SELECT * FROM actions ORDER BY created_at DESC')

    @app.get('/v1/memories')
    async def memories():
        return store.all('SELECT * FROM memories ORDER BY created_at DESC')

    @app.post('/v1/memories')
    async def create_memory(body: Memory):
        item = {'id': uid(), 'content': body.content, 'source': body.source, 'created_at': now(), 'version': 1}
        with store.connect() as db:
            db.execute('INSERT INTO memories VALUES(:id,:content,:source,:created_at,:version)', item)
        return item

    @app.patch('/v1/memories/{mid}')
    async def update_memory(mid: UUID, body: MemoryUpdate):
        with store.connect() as db:
            changed = db.execute('UPDATE memories SET content=?,source=?,version=version+1 WHERE id=? AND version=?',
                                (body.content, body.source, str(mid), body.base_version)).rowcount
            if not changed:
                return error('version_conflict', 'Ce souvenir a changé. Recharge la liste.', 409)
        return store.one('SELECT * FROM memories WHERE id=?', (str(mid),))

    @app.delete('/v1/memories/{mid}')
    async def delete_memory(mid: UUID):
        with store.connect() as db:
            db.execute('DELETE FROM memories WHERE id=?', (str(mid),))
        return {'status': 'deleted', 'backup_warning': 'Les exports antérieurs conservent leurs données.'}

    @app.post('/v1/exports')
    async def export():
        return JSONResponse(store.export(), headers={'Content-Disposition': 'attachment; filename="lumos-export.json"'})

    @app.post('/v1/imports')
    async def restore(request: Request):
        if active:
            return error('turn_running', 'Arrête les conversations avant la restauration.', 409)
        raw = bytearray()
        async for chunk in request.stream():
            raw.extend(chunk)
            if len(raw) > 10 * 1024 * 1024:
                return error('file_too_large', 'Export limité à 10 Mo.', 413)
        try:
            archive = json.loads(raw)
            if archive['schema_version'] != 1:
                raise ValueError()
            expected = {
                'conversations': {'id', 'title', 'created_at'},
                'messages': {'id', 'conversation_id', 'role', 'content', 'status', 'created_at', 'spoken_text', 'client_id'},
                'tasks': {'id', 'title', 'status', 'created_at', 'version'},
                'actions': {'id', 'tool', 'payload', 'state', 'evidence', 'created_at', 'idempotency_key'},
                'memories': {'id', 'content', 'source', 'created_at', 'version'},
            }
            with store.connect() as db:
                if any(db.execute(f'SELECT 1 FROM {t} LIMIT 1').fetchone() for t in expected):
                    return error('profile_not_empty', 'Restaure uniquement dans un profil vierge pour éviter toute résurrection ou fusion silencieuse.', 409)
                for table, fields in expected.items():
                    rows = archive[table]
                    if not isinstance(rows, list) or len(rows) > 10000:
                        raise ValueError()
                    for row in rows:
                        if set(row) != fields or any(not isinstance(v, (str, int, type(None))) for v in row.values()):
                            raise ValueError()
                        UUID(row['id'])
                        columns = sorted(fields)
                        db.execute(f"INSERT INTO {table}({','.join(columns)}) VALUES({','.join('?' for _ in columns)})", [row[k] for k in columns])
        except (ValueError, KeyError, TypeError, sqlite3.Error):
            return error('invalid_export', 'Export invalide ; aucune donnée n’a été importée.', 422)
        return {'status': 'restored'}

    @app.post('/v1/audio/transcribe')
    async def transcribe(audio: UploadFile = File(...)):
        if not whisper_path or not Path(whisper_path, 'model.bin').is_file():
            return error('speech_unavailable', 'Le modèle de transcription local n’est pas installé.', 503)
        content = await audio.read(8 * 1024 * 1024 + 1)
        if len(content) > 8 * 1024 * 1024:
            return error('file_too_large', 'Audio limité à 8 Mo et 30 secondes.', 413)
        def recognize():
            nonlocal whisper
            if not speech_lock.acquire(blocking=False):
                return None
            try:
                import onnxruntime
                onnxruntime.disable_telemetry_events()
                from faster_whisper import WhisperModel
                if whisper is None:
                    if Path(whisper_path).resolve() == ROOT / '.data/models/whisper-small':
                        with Path(whisper_path, 'model.bin').open('rb') as model_file:
                            if hashlib.file_digest(model_file, 'sha256').hexdigest() != '3e305921506d8872816023e4c273e75d2419fb89b24da97b4fe7bce14170d671':
                                raise ValueError('Model checksum mismatch')
                    whisper = WhisperModel(whisper_path, device='cpu', compute_type='int8',
                                           cpu_threads=4, local_files_only=True)
                import av
                with av.open(io.BytesIO(content)) as container:
                    duration = container.duration / av.time_base if container.duration else 0
                    if duration > 31:
                        raise ValueError('duration')
                # Decode incrementally: compressed silence must not allocate hours of audio.
                import numpy as np
                buffers, total = [], 0
                with av.open(io.BytesIO(content)) as container:
                    resampler = av.AudioResampler(format='s16', layout='mono', rate=16000)
                    for frame in container.decode(audio=0):
                        for converted in resampler.resample(frame):
                            chunk = converted.to_ndarray().flatten()
                            total += len(chunk)
                            if total > 31 * 16000:
                                raise ValueError('duration')
                            buffers.append(chunk)
                if not buffers:
                    return ''
                samples = np.concatenate(buffers).astype(np.float32) / 32768.0
                segments, _ = whisper.transcribe(samples, language='fr', beam_size=5, vad_filter=True)
                return ' '.join(segment.text.strip() for segment in segments).strip()
            finally:
                speech_lock.release()
        try:
            text = await asyncio.to_thread(recognize)
            if text is None:
                return error('speech_busy', 'Une transcription est en cours.', 409, True)
            return {'text': text}
        except Exception:
            return error('speech_failed', 'Transcription impossible. Vérifie le modèle local et le format audio.', 422)

    app.mount('/assets', StaticFiles(directory=ROOT / 'apps/web'), name='assets')

    @app.get('/')
    async def index():
        return FileResponse(ROOT / 'apps/web/index.html')

    return app
