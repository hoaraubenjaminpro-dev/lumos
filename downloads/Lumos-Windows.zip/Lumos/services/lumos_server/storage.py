"""SQLite local, transactions atomiques et migration initiale versionnée."""
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from uuid import uuid4


def now():
    return datetime.now(timezone.utc).isoformat()


def uid():
    return str(uuid4())


class Store:
    def __init__(self, path):
        self.path = path
        with self.connect() as db:
            db.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS conversations(
              id TEXT PRIMARY KEY, title TEXT NOT NULL, created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS messages(
              id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL REFERENCES conversations(id),
              role TEXT NOT NULL CHECK(role IN ('user','assistant')), content TEXT NOT NULL,
              status TEXT NOT NULL, created_at TEXT NOT NULL, spoken_text TEXT NOT NULL DEFAULT '',
              client_id TEXT, UNIQUE(conversation_id,client_id));
            CREATE TABLE IF NOT EXISTS tasks(
              id TEXT PRIMARY KEY, title TEXT NOT NULL, status TEXT NOT NULL,
              created_at TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS actions(
              id TEXT PRIMARY KEY, tool TEXT NOT NULL, payload TEXT NOT NULL,
              state TEXT NOT NULL, evidence TEXT NOT NULL, created_at TEXT NOT NULL,
              idempotency_key TEXT UNIQUE NOT NULL);
            CREATE TABLE IF NOT EXISTS memories(
              id TEXT PRIMARY KEY, content TEXT NOT NULL, source TEXT NOT NULL,
              created_at TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1);
            PRAGMA user_version=1;
            ''')
            # A process crash cannot leave an answer presented as complete.
            db.execute("UPDATE messages SET status='interrupted' WHERE status='generating'")

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def all(self, sql, args=()):
        with self.connect() as db:
            return [dict(row) for row in db.execute(sql, args)]

    def one(self, sql, args=()):
        rows = self.all(sql, args)
        return rows[0] if rows else None

    def export(self):
        with self.connect() as db:
            return {'schema_version': 1, 'exported_at': now(),
                    **{table: [dict(r) for r in db.execute(f'SELECT * FROM {table}')]
                       for table in ('conversations', 'messages', 'tasks', 'actions', 'memories')}}

    def task(self, title, key):
        with self.connect() as db:
            old = db.execute('SELECT * FROM actions WHERE idempotency_key=?', (key,)).fetchone()
            if old:
                if json.loads(old['payload']) != {'title': title}:
                    raise ValueError('idempotency_conflict')
                return dict(old)
            task_id, action_id = uid(), uid()
            timestamp = now()
            db.execute('INSERT INTO tasks(id,title,status,created_at) VALUES(?,?,?,?)',
                       (task_id, title, 'open', timestamp))
            db.execute('INSERT INTO actions VALUES(?,?,?,?,?,?,?)',
                       (action_id, 'tasks.create', json.dumps({'title': title}), 'succeeded',
                        json.dumps({'task_id': task_id, 'destination': 'Lumos'}), timestamp, key))
            return dict(db.execute('SELECT * FROM actions WHERE id=?', (action_id,)).fetchone())
