"""Optional explicit local model download (~1.1 GB). No inference on Hugging Face.
Hub download verifies content addressing; TLS verification remains enabled.
"""
import os
import hashlib
from pathlib import Path
root = Path(__file__).resolve().parents[1]
os.environ.setdefault('HF_HOME', str(root / '.data' / 'huggingface'))
from huggingface_hub import hf_hub_download

if __name__ == '__main__':
    target = root / '.data' / 'models'
    try:
        hf_hub_download('Qwen/Qwen2.5-1.5B-Instruct-GGUF',
                        filename='qwen2.5-1.5b-instruct-q4_k_m.gguf',
                        revision='91cad51170dc346986eccefdc2dd33a9da36ead9', local_dir=target)
        with (target / 'qwen2.5-1.5b-instruct-q4_k_m.gguf').open('rb') as f:
            if hashlib.file_digest(f, 'sha256').hexdigest() != '6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e':
                raise ValueError('Checksum mismatch')
        for name in ('LICENSE', 'README.md'):
            hf_hub_download('Qwen/Qwen2.5-1.5B-Instruct-GGUF', filename=name,
                            revision='91cad51170dc346986eccefdc2dd33a9da36ead9',
                            local_dir=target / 'qwen-notices')
    except Exception:
        raise SystemExit('Téléchargement impossible. Vérifie l’accès HTTPS à Hugging Face et ses redirections dans les paramètres réseau. Aucun repli cloud ni modification de TLS.') from None
    print('GGUF local téléchargé. Licence modèle Apache-2.0 à conserver avant redistribution.')
