$ErrorActionPreference = 'Stop';
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;
    $root = $env:LUMOS_ROOT;
    if (-not $root) { throw 'Lance le fichier Demarrer Lumos.cmd.' };
    Set-Location -LiteralPath $root;
    $config = Get-Content -Raw -LiteralPath (Join-Path $root 'packages\windows\runtime.json') | ConvertFrom-Json;
    $runtime = Join-Path $root '.data\runtime\uv';
    $download = Join-Path $root '.data\downloads';
    New-Item -ItemType Directory -Force -Path $runtime,$download | Out-Null;
    $uv = Join-Path $runtime 'uv.exe';
    if (-not (Test-Path -LiteralPath $uv)) {
        Write-Host 'Preparation du lanceur local. Aucun Python a installer manuellement.';
        $archive = Join-Path $download 'uv-windows.zip';
        if (-not (Test-Path -LiteralPath $archive)) { Invoke-WebRequest -UseBasicParsing -Uri $config.uv.url -OutFile ($archive + '.part'); Move-Item -LiteralPath ($archive + '.part') -Destination $archive -Force; };
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $archive).Hash.ToLowerInvariant() -ne $config.uv.sha256) { throw 'Verification du lanceur impossible. Archive refusee.' };
        Expand-Archive -LiteralPath $archive -DestinationPath $runtime -Force;
    };
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $uv).Hash.ToLowerInvariant() -ne $config.uv.executable_sha256) { throw 'Le lanceur local a ete modifie. Il ne sera pas execute.' };
    $env:UV_PYTHON_INSTALL_DIR = Join-Path $root '.data\runtime\python';
    $env:UV_CACHE_DIR = Join-Path $root '.data\cache\uv';
    $env:UV_PYTHON_BIN_DIR = Join-Path $root '.data\runtime\python-bin';
    $env:PYTHONUTF8 = '1';
    & $uv run --no-project --python $config.python (Join-Path $root 'scripts\windows_setup.py');
    exit $LASTEXITCODE;
} catch {
    Write-Host ('Lumos ne peut pas demarrer : ' + $_.Exception.Message) -ForegroundColor Red;
    exit 1;
};
