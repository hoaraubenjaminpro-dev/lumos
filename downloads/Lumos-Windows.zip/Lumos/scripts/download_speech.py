"""Explicit optional ~500 MB download. Preserves TLS; no automatic cloud inference."""
import os
import hashlib
from pathlib import Path
root = Path(__file__).resolve().parents[1]
os.environ.setdefault('HF_HOME', str(root / '.data' / 'huggingface'))
from huggingface_hub import snapshot_download
if __name__ == '__main__':
    target = root / '.data' / 'models' / 'whisper-small'
    try:
        snapshot_download('Systran/faster-whisper-small', local_dir=target,
                          revision='536b0662742c02347bc0e980a01041f333bce120',
                          allow_patterns=['model.bin', 'config.json', 'tokenizer.json', 'vocabulary.*', 'README.md'])
        with (target / 'model.bin').open('rb') as f:
            if hashlib.file_digest(f, 'sha256').hexdigest() != '3e305921506d8872816023e4c273e75d2419fb89b24da97b4fe7bce14170d671':
                raise ValueError('Checksum mismatch')
    except Exception:
        raise SystemExit('Téléchargement STT impossible. Vérifie les autorisations HTTPS Hugging Face dans les paramètres réseau. La conversation texte et les tâches restent indépendantes.') from None
    print('Modèle téléchargé. Définis LUMOS_WHISPER_DIR avec ce chemin :')
    print(target)
