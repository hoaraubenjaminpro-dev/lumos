"""One-click Windows setup. Portable Python is provided by verified uv.
No administrator access unless the official Microsoft VC runtime is missing.
"""
from contextlib import contextmanager
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / '.data'


def sha256(path):
    with Path(path).open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def download_verified(url, destination, expected):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if sha256(destination) == expected:
            return destination
        raise RuntimeError('Une archive en cache est altérée. Aucun exécutable ne sera lancé.')
    # An interrupted download is never mistaken for a finished artifact.
    with tempfile.NamedTemporaryFile(dir=destination.parent, suffix='.part', delete=False) as file:
        partial = Path(file.name)
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'Lumos-local-installer/0.1'})
        with urllib.request.urlopen(request, timeout=60) as source, partial.open('wb') as target:
            shutil.copyfileobj(source, target)
        if sha256(partial) != expected:
            raise RuntimeError('Empreinte SHA-256 incorrecte ; téléchargement refusé.')
        partial.replace(destination)
    finally:
        partial.unlink(missing_ok=True)
    return destination


def extract_verified_zip(archive, destination):
    """Call only after validating the archive hash; restore only declared entries."""
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zipped:
        for entry in zipped.infolist():
            if '\\' in entry.filename or ':' in entry.filename:
                raise RuntimeError('Chemin non autorisé dans une archive.')
            path = (destination / entry.filename).resolve()
            if not path.is_relative_to(destination) or (entry.external_attr >> 16) & 0o170000 == 0o120000:
                raise RuntimeError('Chemin non autorisé dans une archive.')
            if entry.is_dir():
                path.mkdir(parents=True, exist_ok=True)
                continue
            path.parent.mkdir(parents=True, exist_ok=True)
            expected = hashlib.sha256(zipped.read(entry)).hexdigest()
            if path.exists() and sha256(path) == expected:
                continue
            path.write_bytes(zipped.read(entry))


@contextmanager
def install_lock(path):
    import msvcrt
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as file:
        file.seek(0, 2)
        if file.tell() == 0:
            file.write(b'0'); file.flush()
        file.seek(0)
        try:
            msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            raise RuntimeError('Une installation est déjà en cours. Attends l’ouverture de Lumos.') from None
        try:
            yield
        finally:
            file.seek(0)
            msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)


def checked(command):
    result = subprocess.run([str(part) for part in command], cwd=ROOT)
    if result.returncode:
        raise RuntimeError('Cette étape a échoué. Relance Lumos pour reprendre ; tes données sont conservées.')


def ensure_microsoft_runtime():
    try:
        for name in ('msvcp140.dll', 'vcruntime140.dll', 'vcruntime140_1.dll'):
            ctypes.WinDLL(name)
        return
    except OSError:
        pass
    print('Installation du composant Microsoft manquant. Windows peut demander son autorisation.', flush=True)
    # Run only a valid Microsoft-signed installer, never an unsigned download.
    command = r"""
$ErrorActionPreference='Stop';
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;
$path=Join-Path $env:LUMOS_ROOT '.data\downloads\vc_redist.x64.exe';
Invoke-WebRequest -UseBasicParsing -Uri 'https://aka.ms/vs/17/release/vc_redist.x64.exe' -OutFile $path;
$signature=Get-AuthenticodeSignature -LiteralPath $path;
if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'O=Microsoft Corporation,') { throw 'Signature Microsoft invalide : installation refusee.' };
$p=Start-Process -FilePath $path -ArgumentList '/install','/passive','/norestart' -Verb RunAs -Wait -PassThru;
if ($p.ExitCode -notin @(0,3010)) { throw 'Le composant Microsoft ne peut pas etre installe.' };
"""
    checked(['powershell.exe', '-NoLogo', '-NoProfile', '-Command', command])
    try:
        ctypes.WinDLL('msvcp140.dll')
    except OSError:
        raise RuntimeError('Le composant Microsoft nécessite un redémarrage de Windows avant de relancer Lumos.') from None


def models_ready():
    manifest = json.loads((ROOT / 'docs/MODELS.json').read_text(encoding='utf-8'))
    targets = [(DATA / 'models' / manifest['dialogue']['filename'], manifest['dialogue']['sha256']),
               (DATA / 'models/whisper-small/model.bin', manifest['transcription']['sha256'])]
    return all(path.is_file() and sha256(path) == expected for path, expected in targets) and all(
        (DATA / 'models/whisper-small' / name).is_file()
        for name in ('config.json', 'tokenizer.json', 'vocabulary.txt'))


def main():
    if os.name != 'nt':
        raise RuntimeError('Ce lanceur est destiné à Windows 64 bits.')
    if not os.environ.get('PROCESSOR_ARCHITEW6432', os.environ.get('PROCESSOR_ARCHITECTURE', '')).upper() in ('AMD64',):
        raise RuntimeError('Ce paquet nécessite Windows 10 ou 11 sur un PC Intel/AMD 64 bits.')
    os.chdir(ROOT)
    os.environ['LUMOS_ROOT'] = str(ROOT)
    DATA.mkdir(exist_ok=True)
    config = json.loads((ROOT / 'packages/windows/runtime.json').read_text(encoding='utf-8'))
    uv = DATA / 'runtime/uv/uv.exe'
    if not uv.is_file() or sha256(uv) != config['uv']['executable_sha256']:
        raise RuntimeError('Le gestionnaire Python local n’est pas vérifié.')
    python = ROOT / '.venv/Scripts/python.exe'
    if not python.is_file() and shutil.disk_usage(ROOT).free < 4 * 1024**3:
        raise RuntimeError('Prévois au moins 4 Go libres avant la première installation de Lumos.')
    with install_lock(DATA / 'installation.lock'):
        if not python.is_file():
            print('1/4 · Préparation de Python local…', flush=True)
            checked([uv, 'venv', '--python', sys.executable, ROOT / '.venv'])
        requirements = ROOT / 'requirements.lock'
        stamp = DATA / 'runtime/dependencies.sha256'
        digest = sha256(requirements)
        if not stamp.exists() or stamp.read_text().strip() != digest:
            print('2/4 · Installation des composants de Lumos…', flush=True)
            checked([uv, 'pip', 'sync', '--python', python, requirements])
            checked([uv, 'pip', 'check', '--python', python])
            stamp.write_text(digest)
        ensure_microsoft_runtime()
        print('3/4 · Vérification du moteur local…', flush=True)
        asset = config['llama']
        archive = download_verified(asset['url'], DATA / 'downloads/llama-windows.zip', asset['sha256'])
        extract_verified_zip(archive, DATA / 'runtime/llama')
        if not models_ready():
            print('4/4 · Téléchargement des modèles gratuits (~1,6 Go). Patiente, cette étape est unique…', flush=True)
            checked([python, ROOT / 'scripts/download_models.py'])
            checked([python, ROOT / 'scripts/download_speech.py'])
            if not models_ready():
                raise RuntimeError('Les modèles ne sont pas vérifiés. Aucun modèle non vérifié ne sera lancé.')
    print('Lumos est préparé. Ouverture de ton espace…', flush=True)
    checked([python, ROOT / 'scripts/desktop.py'])


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nLancement arrêté. Tu peux reprendre en double-cliquant sur Démarrer Lumos.')
        raise SystemExit(0)
    except Exception as exc:
        print('\nLumos ne peut pas démarrer : ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
