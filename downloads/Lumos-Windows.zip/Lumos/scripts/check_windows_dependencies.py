"""Validate the locked dependency closure using actual Windows wheel metadata.
Pip download --platform alone evaluates some environment markers on the host;
this check explicitly evaluates them for Windows/Python 3.12 instead.
"""
import argparse
from email.parser import BytesParser
from pathlib import Path
import zipfile
from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name


def windows_environment():
    return {**default_environment(), 'os_name':'nt', 'sys_platform':'win32',
            'platform_system':'Windows', 'platform_machine':'AMD64',
            'platform_release':'10', 'platform_version':'10.0.19045',
            'python_version':'3.12', 'python_full_version':'3.12.14',
            'implementation_name':'cpython', 'implementation_version':'3.12.14',
            'platform_python_implementation':'CPython', 'extra':''}


def validate(lock, wheels):
    environment = windows_environment()
    requirements=[]
    for line in Path(lock).read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        item=Requirement(line)
        if item.marker is None or item.marker.evaluate(environment):
            requirements.append(item)
    metadata={}
    for wheel in Path(wheels).glob('*.whl'):
        with zipfile.ZipFile(wheel) as archive:
            names=[name for name in archive.namelist() if name.endswith('.dist-info/METADATA')]
            if len(names)!=1:
                raise ValueError('Invalid wheel metadata: '+wheel.name)
            info=BytesParser().parsebytes(archive.read(names[0]))
            metadata[canonicalize_name(info['Name'])]=info
    errors=[]
    selected={canonicalize_name(item.name):item for item in requirements}
    for name,item in selected.items():
        info=metadata.get(name)
        if info is None:
            errors.append('Windows wheel missing: '+item.name)
            continue
        if info['Version'] not in item.specifier:
            errors.append('Wrong Windows wheel version: '+item.name)
            continue
        for value in info.get_all('Requires-Dist',[]):
            dependency=Requirement(value)
            if dependency.marker is not None and not dependency.marker.evaluate(environment):
                continue
            target=canonicalize_name(dependency.name)
            if target not in selected:
                errors.append(f'{item.name} requires {dependency}: missing from Windows lock')
            elif target in metadata and metadata[target]['Version'] not in dependency.specifier:
                errors.append(f'{item.name} requires {dependency}: incompatible version')
    return errors,len(selected)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--lock',type=Path,default=Path(__file__).resolve().parents[1]/'requirements.lock')
    parser.add_argument('--wheels',type=Path,required=True)
    args=parser.parse_args()
    errors,count=validate(args.lock,args.wheels)
    if errors:
        print('\n'.join(errors))
        raise SystemExit(1)
    print(f'Windows dependency closure verified: {count} pinned packages, no missing or incompatible dependency.')
