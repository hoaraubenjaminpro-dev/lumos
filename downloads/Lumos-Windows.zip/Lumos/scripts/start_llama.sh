#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
model=.data/models/qwen2.5-1.5b-instruct-q4_k_m.gguf
[[ -f "$model" ]] || { echo 'Modèle GGUF absent. Lance .venv/bin/python scripts/download_models.py après autorisation du réseau.' >&2; exit 1; }
printf '%s  %s\n' '6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e' "$model" | sha256sum --check -
exec .data/tools/lib/ollama/llama-server --model "$model" --alias qwen2.5:1.5b --host 127.0.0.1 --port 8081 --threads 4 --ctx-size 4096 --n-gpu-layers 0
