"""No personal files, environment dump, credential or hostname collection."""
import json
import os
import platform
import shutil
import sys
from pathlib import Path

result = {'python': platform.python_version(), 'os': platform.system(),
          'architecture': platform.machine(), 'cpu_threads': os.cpu_count(),
          'disk_free_gib': round(shutil.disk_usage(Path(__file__).resolve().parents[1]).free / 2**30, 1),
          'ollama_executable': bool(shutil.which('ollama')),
          'whisper_configured': bool(os.getenv('LUMOS_WHISPER_DIR'))}
if hasattr(os, 'sysconf') and sys.platform == 'linux':
    result['ram_gib'] = round(os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES') / 2**30, 1)
print(json.dumps(result, indent=2, ensure_ascii=False))
