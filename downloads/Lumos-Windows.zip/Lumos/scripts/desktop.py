"""Local desktop supervisor: start services, authenticate the browser, own shutdown.
No owner secret in URLs, logs or shortcuts. Runtime authentication is single-use.
"""
import argparse
from contextlib import contextmanager
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import webbrowser

import httpx

ROOT = Path(__file__).resolve().parents[1]


class WindowsJob:
    """Terminate only the children this launcher started, including on window close."""
    def __init__(self):
        self.handle = None
        if os.name != 'nt':
            return
        from ctypes import wintypes as W
        class Basic(C.Structure):
            _fields_ = [('PerProcessUserTimeLimit', C.c_int64), ('PerJobUserTimeLimit', C.c_int64),
                        ('LimitFlags', W.DWORD), ('MinimumWorkingSetSize', C.c_size_t),
                        ('MaximumWorkingSetSize', C.c_size_t), ('ActiveProcessLimit', W.DWORD),
                        ('Affinity', C.c_size_t), ('PriorityClass', W.DWORD), ('SchedulingClass', W.DWORD)]
        class Counters(C.Structure):
            _fields_ = [(name, C.c_uint64) for name in ('ReadOperationCount', 'WriteOperationCount',
                         'OtherOperationCount', 'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount')]
        class Limits(C.Structure):
            _fields_ = [('BasicLimitInformation', Basic), ('IoInfo', Counters),
                        ('ProcessMemoryLimit', C.c_size_t), ('JobMemoryLimit', C.c_size_t),
                        ('PeakProcessMemoryUsed', C.c_size_t), ('PeakJobMemoryUsed', C.c_size_t)]
        self.kernel = C.WinDLL('kernel32', use_last_error=True)
        self.kernel.CreateJobObjectW.argtypes = [C.c_void_p, W.LPCWSTR]
        self.kernel.CreateJobObjectW.restype = W.HANDLE
        self.kernel.SetInformationJobObject.argtypes = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD]
        self.kernel.AssignProcessToJobObject.argtypes = [W.HANDLE, W.HANDLE]
        self.kernel.OpenProcess.argtypes = [W.DWORD, W.BOOL, W.DWORD]
        self.kernel.OpenProcess.restype = W.HANDLE
        self.kernel.CloseHandle.argtypes = [W.HANDLE]
        self.handle = self.kernel.CreateJobObjectW(None, None)
        limits = Limits(); limits.BasicLimitInformation.LimitFlags = 0x2000
        if not self.handle or not self.kernel.SetInformationJobObject(self.handle, 9, C.byref(limits), C.sizeof(limits)):
            self.close()
            raise RuntimeError('Windows ne permet pas de superviser les services de Lumos.')

    def add(self, process):
        if not self.handle:
            return
        handle = self.kernel.OpenProcess(0x0101, False, process.pid)
        try:
            if not handle or not self.kernel.AssignProcessToJobObject(self.handle, handle):
                process.terminate(); process.wait(timeout=10)
                raise RuntimeError('Impossible de superviser le service local. Aucun service n’est laissé ouvert.')
        finally:
            if handle:
                self.kernel.CloseHandle(handle)

    def close(self):
        if self.handle:
            self.kernel.CloseHandle(self.handle)
            self.handle = None


C = ctypes


def get_json(base, path):
    try:
        with httpx.Client(trust_env=False, timeout=2) as client:
            response = client.get(base + path)
            response.raise_for_status()
            return response.json()
    except (httpx.HTTPError, ValueError):
        return None


def engine_ready(base):
    if get_json(base, '/health') != {'status': 'ok'}:
        return False
    models = get_json(base, '/v1/models') or {}
    return any(model.get('id') == 'qwen2.5:1.5b' for model in models.get('data', []))


def app_ready(base):
    health = get_json(base, '/health') or {}
    return health.get('status') == 'ok' and health.get('version') == '0.1.0'


def wait_for(predicate, process, timeout, name):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process is not None and process.poll() is not None:
            raise RuntimeError(name + ' s’est arrêté. Le diagnostic se trouve dans .data/desktop/.')
        if predicate():
            return
        time.sleep(.25)
    raise RuntimeError(name + ' n’a pas pu démarrer dans le délai prévu. Consulte .data/desktop/.')


def browser_ticket(base, data):
    owner = data / 'owner-code'
    if not owner.is_file():
        raise RuntimeError('Le port de Lumos est occupé par un autre profil. Aucun processus inconnu ne sera arrêté.')
    with httpx.Client(base_url=base, trust_env=False, timeout=10, headers={'X-Lumos-Request': '1'}) as client:
        response = client.post('/auth/login', json={'code': owner.read_text().strip()})
        if response.status_code != 200:
            raise RuntimeError('Le serveur ouvert ne correspond pas à ce profil Lumos.')
        response = client.post('/v1/browser-launch')
        response.raise_for_status()
        token = response.json()['token']
    return base + '/#launch=' + token


def open_browser(base, data, enabled):
    if enabled and not webbrowser.open(browser_ticket(base, data), new=1):
        raise RuntimeError('Définis un navigateur par défaut dans Windows, puis relance Lumos.')


def shortcut():
    if os.name != 'nt':
        return
    command = r"""
$ErrorActionPreference='Stop';
$path=Join-Path ([Environment]::GetFolderPath('Desktop')) 'Lumos.lnk';
if (-not (Test-Path -LiteralPath $path)) {
 $shell=New-Object -ComObject WScript.Shell;
 $link=$shell.CreateShortcut($path);
 $link.TargetPath=Join-Path $env:LUMOS_ROOT 'Demarrer Lumos.cmd';
 $link.WorkingDirectory=$env:LUMOS_ROOT;
 $link.Description='Ouvrir Lumos, assistant personnel local';
 $link.Save();
};
"""
    subprocess.run(['powershell.exe', '-NoLogo', '-NoProfile', '-Command', command],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


@contextmanager
def desktop_lock(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as file:
        file.seek(0, 2)
        if not file.tell():
            file.write(b'0'); file.flush()
        file.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise BlockingIOError('Un démarrage de Lumos est déjà en cours.') from None
        try:
            yield
        finally:
            if os.name == 'nt':
                file.seek(0); msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(file.fileno(), fcntl.LOCK_UN)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--model-port', type=int, default=8081)
    parser.add_argument('--model-server', type=Path)
    parser.add_argument('--no-browser', action='store_true', help='Contrôles automatisés uniquement')
    args = parser.parse_args(argv)
    if not all(1024 <= port <= 65535 for port in (args.port, args.model_port)):
        raise RuntimeError('Ports locaux invalides.')
    data = Path(os.getenv('LUMOS_DATA_DIR', ROOT / '.data')).resolve()
    data.mkdir(parents=True, exist_ok=True)
    os.environ['LUMOS_ROOT'] = str(ROOT)
    base = f'http://127.0.0.1:{args.port}'
    if app_ready(base):
        open_browser(base, data, not args.no_browser)
        return
    try:
        with desktop_lock(data / 'desktop.lock'):
            run_services(args, base, data)
    except BlockingIOError:
        print('Lumos démarre déjà. Ouverture dès qu’il est prêt…', flush=True)
        wait_for(lambda: app_ready(base), None, 180, 'Lumos')
        open_browser(base, data, not args.no_browser)


def run_services(args, base, data):
    model_base = f'http://127.0.0.1:{args.model_port}'
    processes, logs = [], []
    job = WindowsJob()
    diagnostics = data / 'desktop'; diagnostics.mkdir(exist_ok=True)
    def start(command, name, environment):
        path = diagnostics / (name + '.log')
        if path.is_file() and path.stat().st_size > 1024 * 1024:
            path.replace(path.with_suffix('.previous.log'))
        file = path.open('ab'); logs.append(file)
        process = subprocess.Popen([str(part) for part in command], cwd=ROOT, env=environment,
                                   stdout=file, stderr=file,
                                   creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        processes.append(process); job.add(process)
        return process
    try:
        environment = os.environ.copy()
        environment.update({'LUMOS_BACKEND': 'llamacpp', 'LUMOS_MODEL': 'qwen2.5:1.5b',
                            'LUMOS_OLLAMA_URL': model_base, 'LUMOS_PORT': str(args.port),
                            'LUMOS_DATA_DIR': str(data),
                            'LUMOS_WHISPER_DIR': str(ROOT / '.data/models/whisper-small')})
        if not engine_ready(model_base):
            binary = args.model_server or ROOT / ('.data/runtime/llama/llama-server.exe' if os.name == 'nt' else '.data/tools/lib/ollama/llama-server')
            if not binary.is_file():
                raise RuntimeError('Le moteur local n’est pas installé. Relance Démarrer Lumos.')
            model = ROOT / '.data/models/qwen2.5-1.5b-instruct-q4_k_m.gguf'
            from windows_setup import sha256
            manifest = json.loads((ROOT / 'docs/MODELS.json').read_text(encoding='utf-8'))
            if not model.is_file() or sha256(model) != manifest['dialogue']['sha256']:
                raise RuntimeError('Le modèle local n’est pas vérifié. Aucun modèle non vérifié ne sera lancé.')
            print('Chargement du modèle local…', flush=True)
            process = start([binary, '--model', model, '--alias', 'qwen2.5:1.5b', '--host', '127.0.0.1',
                             '--port', str(args.model_port), '--threads', str(min(4, os.cpu_count() or 2)),
                             '--ctx-size', '4096', '--n-gpu-layers', '0', '--parallel', '1'], 'model', environment)
            wait_for(lambda: engine_ready(model_base), process, 180, 'Le modèle')
        process = start([sys.executable, ROOT / 'scripts/run.py'], 'server', environment)
        wait_for(lambda: app_ready(base), process, 30, 'Le serveur Lumos')
        with httpx.Client(base_url=base, trust_env=False, timeout=10, headers={'X-Lumos-Request': '1'}) as client:
            response = client.post('/auth/login', json={'code': (data / 'owner-code').read_text().strip()})
            response.raise_for_status()
            cap = client.get('/v1/capabilities').json()
            if not cap.get('text') or not cap.get('speech_input'):
                raise RuntimeError('Les modèles ne sont pas disponibles. Consulte le diagnostic local.')
        shortcut()
        open_browser(base, data, not args.no_browser)
        print('Lumos est ouvert. Garde cette fenêtre ouverte pendant ton essai.', flush=True)
        print('Pour arrêter Lumos : Ctrl+C ou ferme cette fenêtre.', flush=True)
        while True:
            for child in processes:
                if child.poll() is not None:
                    raise RuntimeError('Un service s’est arrêté. Relance Lumos ; tes échanges sont conservés.')
            time.sleep(.5)
    finally:
        for child in reversed(processes):
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait(timeout=5)
        job.close()
        for file in logs:
            file.close()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nLumos est arrêté. Tes données sont conservées.')
    except Exception as exc:
        print('Lumos ne peut pas démarrer : ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
