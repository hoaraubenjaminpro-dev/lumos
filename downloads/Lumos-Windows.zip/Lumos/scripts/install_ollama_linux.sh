#!/usr/bin/env bash
# Official Linux amd64 distribution, CPU profile. ~1.5 GB download, ~300 MB retained.
set -euo pipefail
cd "$(dirname "$0")/.."
[[ "$(uname -s)" == Linux && "$(uname -m)" == x86_64 ]] || { echo 'Ce script cible Linux x86_64.' >&2; exit 1; }
mkdir -p .data/downloads .data/tools
archive=.data/downloads/ollama-linux-amd64.tar.zst
expected=7bedab90dd122661be78798e9f0edf37fccf0cccf2699d2c58ea1a3afdc04b6d
if [[ ! -f "$archive" ]]; then
  curl --fail --location --retry 2 --max-time 300 https://github.com/ollama/ollama/releases/download/v0.40.11/ollama-linux-amd64.tar.zst --output "$archive"
fi
printf '%s  %s\n' "$expected" "$archive" | sha256sum --check -
tar --zstd --exclude='lib/ollama/cuda*' --exclude='lib/ollama/vulkan*' -xf "$archive" -C .data/tools
.data/tools/bin/ollama --version
