"""Run from any directory. Local interface only; no public preview server."""
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

if __name__ == '__main__':
    import uvicorn
    from services.lumos_server.app import create_app
    uvicorn.run(create_app(), host='127.0.0.1', port=int(os.getenv('LUMOS_PORT', '8000')), access_log=False)
