"""Build a private source/launcher bundle. Never include runtime, secrets or user data."""
import argparse
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def write_launcher(root=ROOT):
    script = (root / 'scripts/bootstrap_windows.ps1').read_text(encoding='utf-8')
    # Local, auditable inline command. No ExecutionPolicy override or remote script execution.
    command = ' '.join(line.strip() for line in script.splitlines() if line.strip())
    if '"' in command or len(command) > 7000:
        raise ValueError('Bootstrap cannot be quoted safely in the Windows command file.')
    text = ('@echo off\r\nsetlocal DisableDelayedExpansion\r\nchcp 65001 >nul\r\n'
            'title Lumos\r\ncd /d "%~dp0"\r\nset "LUMOS_ROOT=%~dp0"\r\n'
            'echo Lumos - ton assistant personnel local\r\n'
            'echo Premier lancement : Internet et plusieurs minutes sont necessaires.\r\n'
            'echo.\r\n'
            'powershell.exe -NoLogo -NoProfile -Command "' + command + '"\r\n'
            'set "lumos_exit=%errorlevel%"\r\n'
            'if not "%lumos_exit%"=="0" pause\r\nexit /b %lumos_exit%\r\n')
    (root / 'Demarrer Lumos.cmd').write_bytes(text.encode('utf-8'))


def build(destination, root=ROOT):
    write_launcher(root)
    allowed = {'apps', 'services', 'scripts', 'docs', 'packages', 'tests'}
    root_files = {'README.md', 'requirements.lock', 'requirements.in', 'requirements-browser.lock',
                  'requirements-speech-test.lock', '.env.example', 'Demarrer Lumos.cmd',
                  'LIRE-MOI-WINDOWS.txt', '.gitignore'}
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(root.rglob('*')):
            relative = path.relative_to(root)
            if not path.is_file() or path.is_symlink():
                continue
            if any(part.startswith('.') or part == '__pycache__' for part in relative.parts[:-1]):
                continue
            if path.suffix in ('.pyc', '.log', '.zip', '.sqlite3'):
                continue
            if (len(relative.parts) == 1 and path.name in root_files) or relative.parts[0] in allowed:
                archive.write(path, 'Lumos/' + relative.as_posix())
    with destination.open('rb') as file:
        digest = hashlib.file_digest(file, 'sha256').hexdigest()
    destination.with_suffix('.zip.sha256').write_text(digest + '  ' + destination.name + '\n')
    return destination, digest


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=ROOT.parent / 'releases/Lumos-Windows.zip')
    args = parser.parse_args()
    file, checksum = build(args.output)
    print(file)
    print('SHA-256:', checksum)
