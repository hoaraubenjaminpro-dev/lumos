$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
python -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Python 3.12 est requis.' }
& .venv\Scripts\python.exe -m pip install --disable-pip-version-check -r requirements.lock
if ($LASTEXITCODE -ne 0) { throw 'Installation impossible. Consulte la sortie pip.' }
& .venv\Scripts\python.exe -m pip check
if ($LASTEXITCODE -ne 0) { throw 'Dépendances incompatibles.' }
