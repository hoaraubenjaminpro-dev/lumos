"""Display only on the owner's terminal. Never include in exports or logs."""
import os
from pathlib import Path
root = Path(__file__).resolve().parents[1]
path = Path(os.getenv('LUMOS_DATA_DIR', root / '.data')).resolve() / 'owner-code'
if not path.exists():
    raise SystemExit('Démarre le serveur une première fois pour créer le code local.')
print(path.read_text().strip())
