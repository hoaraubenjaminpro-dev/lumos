import {VoiceSession} from './voice.js';
const $ = s => document.querySelector(s);
let conversationId, capabilities, busy = false, requestController, generation = 0;
let lastReply, spokenText = '', taskRequest;
const voice = new VoiceSession({
  onText: text => send(text),
  onInterrupt: () => interrupt(),
  onState: text => { $('#voice-status').textContent = text; },
  onError: text => { notice(text); updateVoiceButton(); },
  onSpoken: text => {
    spokenText = text;
    if (lastReply) api(`/v1/messages/${lastReply}/spoken`, {method:'POST', body:{text}}).catch(() => {});
  }
});
function node(tag, text, className) { const el=document.createElement(tag); if(text!==undefined) el.textContent=text; if(className) el.className=className; return el; }
function notice(text='') { $('#notice').hidden=!text; $('#notice').textContent=text; }
async function api(path, {method='GET', body, signal, raw=false}={}) {
  const headers={'X-Lumos-Request':'1'};
  if(body!==undefined && !(body instanceof FormData)) headers['Content-Type']='application/json';
  const response=await fetch(path,{method,headers,body:body===undefined?undefined:body instanceof FormData?body:JSON.stringify(body),signal});
  if(!response.ok){const detail=await response.json().catch(()=>({})); if(response.status===401){voice.stop();$('#workspace').hidden=true;$('#login').hidden=false;} throw new Error(detail.error?.message || `Erreur ${response.status}`);}
  return raw?response:response.json();
}
function showView(name) {
  document.querySelectorAll('.view').forEach(el=>el.hidden=el.id!==`${name}-view`);
  document.querySelectorAll('nav button').forEach(el=>el.classList.toggle('selected',el.dataset.view===name));
  $('#page-title').textContent={chat:'Conversation',tasks:'Tâches',memory:'Mémoire',activity:'Activité',settings:'Réglages'}[name];
  if(name!=='chat') interrupt(true);
  Promise.resolve(({tasks:loadTasks,memory:loadMemories,activity:loadActions,settings:loadSettings}[name]||(()=>{}))()).catch(e=>notice(e.message));
}
document.querySelectorAll('[data-view]').forEach(button=>button.onclick=()=>showView(button.dataset.view));
// Settings remain reachable on narrow screens without increasing bottom navigation.
$('header').onclick=event=>{if(innerWidth<=760 && event.target.id==='connection') showView('settings');};
function messageElement(message) {
  const el=node('article',undefined,`message ${message.role}`);
  el.append(node('span',message.content || (message.status==='failed'?'Réponse indisponible.':message.status==='generating'?'Lumos réfléchit…':'Réponse interrompue.')));
  const status={failed:'Échec · aucun succès d’action implicite',interrupted:'Interrompu',generating:'En cours'}[message.status];
  if(message.role==='assistant') el.append(node('small',status || 'Lumos · réponse de conversation', 'meta'));
  return el;
}
async function refreshConversations() {
  const rows=await api('/v1/conversations'); const container=$('#conversations'); container.replaceChildren();
  rows.forEach(row=>{const button=node('button',row.title,row.id===conversationId?'active':'');button.onclick=()=>openConversation(row.id);container.append(button);});
  return rows;
}
async function openConversation(id) {
  if(busy || voice.enabled) await interrupt(true);
  conversationId=id; showView('chat');
  const rows=await api(`/v1/conversations/${id}/messages`);
  $('#messages').replaceChildren(...rows.map(messageElement));$('#welcome').hidden=rows.length>0;
  await refreshConversations(); window.scrollTo(0,document.body.scrollHeight);
}
async function newConversation(title='Nouvelle conversation', preserveVoice=false) {
  if(busy || (voice.enabled && !preserveVoice)) await interrupt(true);
  const row=await api('/v1/conversations',{method:'POST',body:{title}});
  conversationId=row.id; $('#messages').replaceChildren();$('#welcome').hidden=false;showView('chat');await refreshConversations();
}
$('#new-chat').onclick=()=>newConversation().catch(e=>notice(e.message));
function setBusy(value){busy=value;$('#send').disabled=value;$('#stop').disabled=!value&&!voice.speaking;}
async function interrupt(closeVoice=false){
  const playbackMessage=voice.speaking ? lastReply : null;
  generation++; voice.interrupt();
  if(closeVoice){voice.stop();updateVoiceButton();}
  requestController?.abort(); requestController=null;setBusy(false);
  if(conversationId) await api(`/v1/conversations/${conversationId}/interrupt${playbackMessage ? '?message_id='+playbackMessage : ''}`,{method:'POST'}).catch(()=>{});
}
$('#stop').onclick=()=>interrupt();
async function send(content) {
  content=content.trim(); if(!content) return;
  if(busy || voice.speaking) await interrupt();
  if(!conversationId) await newConversation(content.slice(0,60), true);
  const myGeneration=++generation;
  notice();setBusy(true);lastReply=null;spokenText='';$('#welcome').hidden=true;
  const user=messageElement({role:'user',content,status:'complete'});
  const reply=messageElement({role:'assistant',content:'Lumos réfléchit…',status:'generating'});
  $('#messages').append(user,reply); $('#message').value='';window.scrollTo(0,document.body.scrollHeight);
  requestController=new AbortController();
  let responseText='';
  try{
    const response=await api(`/v1/conversations/${conversationId}/messages`,{method:'POST',body:{content,client_id:crypto.randomUUID()},signal:requestController.signal,raw:true});
    const reader=response.body.getReader(), decoder=new TextDecoder();let buffer='';
    const handle=event=>{
      if(myGeneration!==generation) return;
      lastReply=event.message_id;
      if(event.type==='assistant.text') {responseText=event.text;reply.firstChild.textContent=responseText;reply.querySelector('.meta').textContent='Lumos · aucune action externe exécutée';if(voice.enabled) voice.speak(responseText);}
      if(event.type==='action.updated') {loadTasks().catch(()=>{});}
      if(event.type==='error'){reply.firstChild.textContent=event.message;reply.querySelector('.meta').textContent='Réponse indisponible · message conservé';voice.stop();updateVoiceButton();notice(event.message);}
    };
    while(true){const {value,done}=await reader.read();buffer+=decoder.decode(value,{stream:!done});const lines=buffer.split('\n');buffer=lines.pop();for(const line of lines) if(line) handle(JSON.parse(line));if(done){if(buffer.trim())handle(JSON.parse(buffer));break;}}
    if(!responseText && myGeneration===generation) reply.querySelector('.meta').textContent='Réponse indisponible ou interrompue';
  }catch(error){
    if(error.name!=='AbortError'){notice(error.message);reply.firstChild.textContent=error.message;voice.stop();updateVoiceButton();}
    reply.querySelector('.meta').textContent='Interrompu ou échec · consulte l’historique';
  }finally{if(myGeneration===generation){setBusy(false);$('#stop').disabled=!voice.speaking;}refreshConversations().catch(()=>{});}
}
$('#composer').onsubmit=event=>{event.preventDefault();send($('#message').value).catch(e=>notice(e.message));};
$('#message').onkeydown=event=>{if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();$('#composer').requestSubmit();}};
document.querySelectorAll('[data-prompt]').forEach(button=>button.onclick=()=>{ $('#message').value=button.dataset.prompt;$('#message').focus();});
function updateVoiceButton() {$('#voice').setAttribute('aria-pressed',String(voice.enabled));$('#voice span').textContent=voice.enabled?'Fermer le micro':'Parler';}
$('#voice').onclick=async()=>{if(voice.enabled){await interrupt(true);}else{try{capabilities=await api('/v1/capabilities');if(!capabilities.text)throw new Error('Installe et démarre le modèle local avant d’activer la conversation vocale.');if(!capabilities.speech_input)throw new Error('Le modèle de transcription local n’est pas installé. Consulte docs/SETUP.md.');await voice.start();}catch(e){notice(e.message);}updateVoiceButton();}};
async function loadTasks(){
  const rows=await api('/v1/tasks');$('#task-count').textContent=rows.filter(t=>t.status==='open').length;const container=$('#tasks');container.replaceChildren();
  if(!rows.length)container.append(node('p','Un peu de place pour ce qui compte. Ajoute ta première tâche.'));
  rows.forEach(task=>{const row=node('label',undefined,`task-row ${task.status}`),checkbox=node('input');checkbox.type='checkbox';checkbox.checked=task.status==='done';checkbox.onchange=async()=>{try{await api(`/v1/tasks/${task.id}`,{method:'PATCH',body:{status:checkbox.checked?'done':'open',base_version:task.version}});}catch(e){notice(e.message);}await loadTasks();};row.append(checkbox,node('span',task.title));container.append(row);});
}
$('#task-title').oninput=()=>taskRequest=null;
$('#task-form').onsubmit=async event=>{event.preventDefault();const title=$('#task-title').value.trim();if(!title)return;taskRequest??={title,idempotency_key:crypto.randomUUID()};try{await api('/v1/tasks',{method:'POST',body:taskRequest});$('#task-title').value='';taskRequest=null;await loadTasks();notice('La tâche est enregistrée dans Lumos. Aucun rappel système n’a été programmé.');}catch(e){notice(e.message);}};
async function loadMemories(){
  const rows=await api('/v1/memories');$('#memories').replaceChildren();
  rows.forEach(memory=>{const row=node('article',undefined,'memory-row');row.append(node('p',memory.content),node('small',`${memory.source} · ${new Date(memory.created_at).toLocaleDateString('fr-FR')}`));
    const edit=node('button','Corriger');edit.onclick=async()=>{const content=prompt('Corriger ce souvenir',memory.content);if(!content?.trim())return;try{await api(`/v1/memories/${memory.id}`,{method:'PATCH',body:{content,source:'Correction explicite',base_version:memory.version}});await loadMemories();}catch(e){notice(e.message);}};
    const remove=node('button','Oublier');remove.onclick=async()=>{if(!confirm('Supprimer ce souvenir du carnet ? Les anciens exports le conservent.'))return;try{await api(`/v1/memories/${memory.id}`,{method:'DELETE'});await loadMemories();}catch(e){notice(e.message);}};row.append(edit,remove);$('#memories').append(row);
  });
  if(!rows.length)$('#memories').append(node('p','Rien n’est mémorisé automatiquement. Tu gardes la main.'));
}
$('#memory-form').onsubmit=async event=>{event.preventDefault();try{await api('/v1/memories',{method:'POST',body:{content:$('#memory-content').value}});$('#memory-content').value='';await loadMemories();}catch(e){notice(e.message);}};
async function loadActions(){const rows=await api('/v1/actions');$('#actions').replaceChildren();rows.forEach(action=>{const row=node('article',undefined,'card');row.append(node('h2','Tâche interne enregistrée'),node('p',JSON.parse(action.payload).title),node('p',`Réussie · Lumos · ${new Date(action.created_at).toLocaleString('fr-FR')}`),node('code',`Preuve : ${JSON.parse(action.evidence).task_id}`));$('#actions').append(row);});if(!rows.length)$('#actions').append(node('p','Aucune action réalisée pour le moment.'));}
async function loadSettings(){capabilities=await api('/v1/capabilities');renderCapabilities();voice.populateVoices($('#voice-select'));}
function renderCapabilities(){const rows=[['Conversation texte',capabilities.text?`Disponible · ${capabilities.model}`:'Modèle local absent ou injoignable'],['Transcription',capabilities.speech_input?'Modèle local présent · essai micro requis':'Modèle local absent'],['Tâches & historique','Disponibles · SQLite local'],['Export / restauration','Disponibles · JSON versionné'],['Mémoire conversationnelle','Carnet seul · récupération IA à développer'],['Apple, mail & appairage','Non pris en charge dans cette version']];$('#capabilities').replaceChildren(...rows.map(([label,value])=>{const row=node('div',undefined,'cap-row');row.append(node('span',label),node('span',value));return row;}));}
$('#export').onclick=async()=>{try{const response=await api('/v1/exports',{method:'POST',raw:true});const url=URL.createObjectURL(await response.blob()),a=node('a');a.href=url;a.download='lumos-export.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);$('#transfer-status').textContent='Export téléchargé.';}catch(e){notice(e.message);}};
$('#import').onchange=async event=>{const file=event.target.files[0];if(!file)return;try{if(file.size>10*1024*1024)throw new Error('Export limité à 10 Mo.');const body=JSON.parse(await file.text());await api('/v1/imports',{method:'POST',body});$('#transfer-status').textContent='Restauration terminée.';await initialize();}catch(e){notice(e.message);}event.target.value='';};
$('#login-form').onsubmit=async event=>{event.preventDefault();try{await api('/auth/login',{method:'POST',body:{code:$('#code').value}});$('#code').value='';await initialize();}catch(e){$('#login-error').textContent=e.message;}};
$('#logout').onclick=async()=>{await interrupt(true);await api('/v1/logout',{method:'POST'});location.reload();};
async function initialize(){capabilities=await api('/v1/capabilities');$('#workspace').hidden=false;$('#login').hidden=true;$('#connection').textContent=capabilities.text?'● Modèle local disponible':'○ Modèle à configurer';$('#connection').tabIndex=0;$('#connection').setAttribute('role','button');$('#connection').onclick=()=>showView('settings');$('#connection').onkeydown=e=>{if(e.key==='Enter')showView('settings');};if(!capabilities.text)notice('Le modèle local n’est pas disponible. Tu peux déjà créer tes tâches, conserver des informations et exporter tes données.');const rows=await refreshConversations();if(rows.length)await openConversation(rows[0].id);await loadTasks();}
window.addEventListener('offline',()=>{interrupt(true);notice('Connexion interrompue. Le contenu affiché reste visible ; aucune nouvelle action n’est confirmée.');});
document.addEventListener('visibilitychange',()=>{if(document.hidden)interrupt(true);});
async function launch(){
  const token=new URLSearchParams(location.hash.slice(1)).get('launch');
  if(token){
    // Remove the one-use token before any request or display of the application.
    history.replaceState(null,'',location.pathname+location.search);
    try{await api('/auth/bootstrap',{method:'POST',body:{code:token}});}
    catch(error){$('#login-error').textContent=error.message;}
  }
  await initialize();
}
launch().catch(()=>{});
