/** Local audio capture and turn-level VAD. No Web Speech recognition/cloud fallback. */
export class VoiceSession {
  constructor(callbacks){this.cb=callbacks;this.enabled=false;this.speaking=false;this.voices=[];this.epoch=0;this.pending=false;this.currentVoice=null;}
  populateVoices(select){
    const refresh=()=>{this.voices=(window.speechSynthesis?.getVoices()||[]).filter(v=>v.localService&&v.lang.startsWith('fr'));select.replaceChildren();this.voices.forEach(v=>{const option=document.createElement('option');option.textContent=v.name;option.value=v.voiceURI;select.append(option);});if(!this.voices.length){const option=document.createElement('option');option.textContent='Aucune voix française locale détectée';select.append(option);}select.onchange=()=>this.currentVoice=this.voices.find(v=>v.voiceURI===select.value);};
    refresh();if(window.speechSynthesis)window.speechSynthesis.onvoiceschanged=refresh;
  }
  async start(){
    if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder||!window.AudioContext)throw new Error('La capture audio n’est pas disponible. Utilise un navigateur compatible sur localhost ou HTTPS.');
    if(!window.speechSynthesis)throw new Error('La synthèse vocale n’est pas disponible sur cet appareil.');
    this.voices=speechSynthesis.getVoices().filter(v=>v.localService&&v.lang.startsWith('fr'));
    if(!this.voices.length)throw new Error('Installe une voix française locale dans les réglages de ton système, puis recharge la page.');
    try{
      this.stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
      this.context=new AudioContext();await this.context.resume();
      this.source=this.context.createMediaStreamSource(this.stream);this.analyser=this.context.createAnalyser();this.analyser.fftSize=1024;this.source.connect(this.analyser);
      this.buffer=new Float32Array(this.analyser.fftSize);this.enabled=true;this.epoch++;this.cb.onState('Je t’écoute · casque recommandé');
      this.startTime=0;this.lastSound=0;this.loudSince=0;
      this.stream.getAudioTracks().forEach(track=>track.onended=()=>{if(this.enabled){this.stop();this.cb.onError('Micro déconnecté. Réactive la voix après avoir choisi ton entrée audio.');}});
      navigator.mediaDevices.addEventListener('devicechange',this.deviceChange=()=>{this.stop();this.cb.onError('Périphérique audio modifié. Vérifie la sortie puis réactive la voix.');});
      this.tick();
    }catch(error){this.stop();throw error;}
  }
  tick(){
    if(!this.enabled)return;
    this.analyser.getFloatTimeDomainData(this.buffer);const rms=Math.sqrt(this.buffer.reduce((sum,x)=>sum+x*x,0)/this.buffer.length),now=performance.now();
    // Echo cancellation is device-dependent; a headset is required for initial qualification.
    const loud=rms>(this.speaking?0.075:0.025);
    if(loud){if(!this.loudSince)this.loudSince=now;this.lastSound=now;}else this.loudSince=0;
    if(!this.recorder&&this.loudSince&&now-this.loudSince>120&&!this.pending){
      if(this.speaking){this.cb.onInterrupt();this.interrupt();}
      this.record();this.startTime=now;this.cb.onState('Tu parles…');
    }
    if(this.recorder&&(now-this.lastSound>950||now-this.startTime>29500))this.finishRecording();
    this.frame=requestAnimationFrame(()=>this.tick());
  }
  record(){
    const types=['audio/webm;codecs=opus','audio/mp4','audio/webm'];const mimeType=types.find(type=>MediaRecorder.isTypeSupported(type));
    this.parts=[];this.bytes=0;
    this.recorder=new MediaRecorder(this.stream,mimeType?{mimeType}:{});
    this.recorder.ondataavailable=event=>{if(event.data.size){this.parts.push(event.data);this.bytes+=event.data.size;if(this.bytes>8*1024*1024){this.stop();this.cb.onError('Limite audio atteinte. Réactive le micro pour continuer.');}}};
    this.recorder.start(200);
  }
  finishRecording(){
    const recorder=this.recorder;if(!recorder)return;this.recorder=null;
    const epoch=this.epoch;this.pending=true;
    recorder.onstop=async()=>{
      if(!this.enabled||epoch!==this.epoch){this.pending=false;return;}
      const blob=new Blob(this.parts,{type:recorder.mimeType});this.parts=[];
      const form=new FormData();form.append('audio',blob,'turn.audio');this.cb.onState('Je transcris sur ton serveur…');
      this.transcription=new AbortController();
      try{
        const response=await fetch('/v1/audio/transcribe',{method:'POST',headers:{'X-Lumos-Request':'1'},body:form,signal:this.transcription.signal});
        const result=await response.json();if(!response.ok)throw new Error(result.error?.message||'La transcription a échoué.');
        if(this.enabled&&epoch===this.epoch&&result.text){this.cb.onState('Lumos réfléchit…');this.cb.onText(result.text);}
        else if(this.enabled)this.cb.onState('Je t’écoute');
      }catch(error){if(error.name!=='AbortError'){this.stop();this.cb.onError(error.message);}}
      finally{this.pending=false;}
    };
    recorder.stop();
  }
  speak(text){
    if(!this.enabled)return;
    this.interrupt();this.speaking=true;const epoch=this.epoch;this.cb.onState('Lumos parle · tu peux l’interrompre');
    const chunks=text.match(/[^.!?]+[.!?]*\s*/g)||[text];let spoken='';
    const next=()=>{
      if(!this.enabled||epoch!==this.epoch)return;
      const chunk=chunks.shift();if(!chunk){this.speaking=false;this.cb.onState('Je t’écoute');return;}
      const utterance=new SpeechSynthesisUtterance(chunk);utterance.voice=this.currentVoice||this.voices[0];utterance.lang='fr-FR';utterance.rate=1;
      utterance.onend=()=>{if(epoch!==this.epoch)return;spoken+=chunk;this.cb.onSpoken(spoken);next();};
      utterance.onerror=event=>{if(epoch!==this.epoch||event.error==='canceled'||event.error==='interrupted')return;this.stop();this.cb.onError('La voix locale s’est arrêtée. Vérifie la sortie audio.');};
      speechSynthesis.speak(utterance);
    };next();
  }
  interrupt(){this.epoch++;window.speechSynthesis?.cancel();this.speaking=false;if(this.enabled)this.cb.onState('Je t’écoute · interrompu');}
  stop(){
    this.enabled=false;this.interrupt();cancelAnimationFrame(this.frame);this.transcription?.abort();
    if(this.recorder&&this.recorder.state!=='inactive'){this.recorder.onstop=null;this.recorder.stop();}this.recorder=null;this.parts=[];
    this.stream?.getTracks().forEach(track=>track.stop());this.source?.disconnect();this.context?.close().catch(()=>{});
    if(this.deviceChange)navigator.mediaDevices?.removeEventListener('devicechange',this.deviceChange);
    this.pending=false;this.cb.onState('Micro désactivé');
  }
}
